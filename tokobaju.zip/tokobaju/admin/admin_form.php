<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationPassword.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryValidationPassword.js" type="text/javascript"></script>
<form id="form1" name="form1" method="post" action="admin_tambah.php">
  <table width="400" border="0" align="left">
    <tr>
      <td width="10%" align="left" valign="top">Username </td>
      <td width="1%" align="left" valign="top">:</td>
      <td width="89%" align="left" valign="top"><span id="sprytextfield1">
        <label for="text1"></label>
        <input type="text" name="usertxt" id="usertxt" />
      <span class="textfieldRequiredMsg">A value is required.</span></span></span></td>
    </tr>
    <tr>
      <td align="left" valign="top">Password </td>
      <td align="left" valign="top">:</td>
      <td align="left" valign="top"><label></label>
        <label></label>
        <span id="sprypassword1">
        <label for="password1"></label>
        <input type="password" name="pswtxt" id="pswtxt" />
        <span class="passwordRequiredMsg">Password Raoleh Kosong.</span></span>        <span class="Font_Info_Psw">*Maksimal 10 karakter</span></span></td>
    </tr>
    <tr>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top"><label>
        <input type="submit" name="Submit" value="Simpan" />
      </label>
        <label>
          <input type="reset" name="Submit2" value="Batal" />
        </label>
        </span></td>
    </tr>
  </table>
</form>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprypassword1 = new Spry.Widget.ValidationPassword("sprypassword1");
</script>
