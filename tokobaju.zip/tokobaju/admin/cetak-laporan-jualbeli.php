<?php


//file pendukung class pdf dan koneksi ke database
require("../config.php");
include ('class.ezpdf.php');

//Pengaturan kertas untuk saat ini tipe kertas A4

 if (isset($_POST['cetak'])) {
        $dari=$_POST['dari'];
        $sampai=$_POST['sampai'];
        echo $dari;
        echo $sampai;
$pdf =& new Cezpdf('A1','portrait');


    // Atur margin
    $pdf->ezSetCmMargins(1, 3, 3, 3);

    $pdf->addObject($all, 'all');
    $pdf->closeObject();
    
    
    //baris kode dibawah ini digunakan untuk mencetak info toko dalam pdf
    $pdf->ezText('ShockingLabs', 25, array('justification' => 'center'));
    $pdf->ezText('LAPORAN DATA PENJUALAN', 15, array('justification' => 'center'));
    $pdf->ezText('Studi Kasus Toko Baju Online dengan PHP & MySQL', 15, array('justification' => 'center'));
    $pdf->ezSetDy(-10);
    $pdf->ezText('Ody Permana', 12, array('justification' => 'center'));
    $pdf->ezText('Jl. Cendrawasih no 21 A, Demangan, Yogyakarta', 10, array('justification' => 'center'));
    $pdf->ezText('shockinglabs.com / Phome : 08157916364 / BB : 27D70E1', 10, array('justification' => 'center'));
    
    $pdf->ezSetDy(-10); //perintah untuk memberikan jarak spasi paragraf
    
    //$pdf->line(50,1500,2273,1500); //perintah untuk membuat garis atas tabel
          
    $pdf->ezSetDy(-10);

    $pdf->ezText('LAPORAN LABA RUGI DARI TANGGAL: '.$dari.' SAMPAI  '.$sampai.'  ' , 12, array('justification' => 'center'));

    $pdf->ezSetDy(-10);
    
//$sql1 = mysql_query("SELECT * FROM transaksitbl");    
//$hasil = mysql_query($sql1);
//$numrows = mysql_num_rows($sql1);

   //echo "Pengulangan ke " . $x . "<br/>;

//while($cari = mysql_fetch_array($sql1)) {
    //$idx= $cari['notransaksi'];
    //$pdf->ezText($idx, 13, array('justification' => 'LEFT'));

//for($x=$cari['notransaksi']; $x<=$numrows; $x++)
//{
  
  $sql = mysql_query("select *,sum(pembeliantbl.total_beli) as totalbeli,sum(transaksirincitbl.subtotal) as totaljual,barangtbl.nama,barangtbl.id 
from barangtbl,pembeliantbl,transaksirincitbl 
where 
transaksirincitbl.id=barangtbl.id 
and pembeliantbl.id_barangtbl=barangtbl.id 
and (transaksirincitbl.tanggal >='$dari' and transaksirincitbl.tanggal<='$sampai') 
group by barangtbl.id");    
    $i = 1;
    while($tampil = mysql_fetch_array($sql)) {
    $hasilakhir=$tampil['totaljual']- $tampil['totalbeli'];
if ($hasilakhir>=0) { 
$akhirnya= "UNTUNG SEBESAR : Rp." .number_format($hasilakhir ,0, ',', '.') ; 
}
 else if ($hasilakhir<0) { 
$akhirnya= "RUGI SEBESAR : Rp." .number_format($hasilakhir ,0, ',', '.') ; 

    }


   


      $format_harga  = "Rp. ".number_format($tampil['totalbeli'], 0, ',', '.');  //format angka
      $format_total  = "Rp. ".number_format($tampil['totaljual'], 0, ',', '.'); //format angka
      $semua=$tampil['total'];
                  //$totalproduk = $hargaproduk*$jumlah;
            //$totalsemua = ($totalsemua+$totalproduk);
      $totalsemua=($totalsemua+$semua);
       $ody="asdasdas";
      $data[$i]=array(
              'ID'=> $tampil['id'],    
              'NAMA PRODUK'=>$tampil['nama'],
              'TOTAL PEMBELIAN'=>$format_harga,
              'TOTAL PENJUALAN'=>$format_total,
              'KETERANGAN' =>$akhirnya,

              
              
              );
                
      $i++;
        

    }
    
//$x++;
//}
//}
    //perintah untuk mengatur teks yang di cetak pada pdf
    //$pdf->ezStartText(100, 557, 12);
    //$pdf->ezStartText2(500, 557, 12);
    $pdf->ezStartPageNumbers(35, 15, 10);
    $pdf->ezTable($data, '', '', '');

    $pdf->ezSetDy(-50);
    
    $pdf->ezText('NB :', 13, array('justification' => 'LEFT')); //membuat teks NB di bawah tabel
    
    $pdf->ezStream();

  }
?>
