<?php


//file pendukung class pdf dan koneksi ke database
require("../config.php");
include ('class.ezpdf.php');

//Pengaturan kertas untuk saat ini tipe kertas A4

 if (isset($_POST['cetak'])) {
        $dari=$_POST['dari'];
        $sampai=$_POST['sampai'];
        echo $dari;
        echo $sampai;
$pdf =& new Cezpdf('A1','portrait');


    // Atur margin
    $pdf->ezSetCmMargins(1, 3, 3, 3);

    $pdf->addObject($all, 'all');
    $pdf->closeObject();
    
    
    //baris kode dibawah ini digunakan untuk mencetak info toko dalam pdf
    $pdf->ezText('ShockingLabs', 25, array('justification' => 'center'));
    $pdf->ezText('LAPORAN DATA PENJUALAN', 15, array('justification' => 'center'));
    $pdf->ezText('Studi Kasus Toko Baju Online dengan PHP & MySQL', 15, array('justification' => 'center'));
    $pdf->ezSetDy(-10);
    $pdf->ezText('Ody Permana', 12, array('justification' => 'center'));
    $pdf->ezText('Jl. Cendrawasih no 21 A, Demangan, Yogyakarta', 10, array('justification' => 'center'));
    $pdf->ezText('shockinglabs.com / Phome : 08157916364 / BB : 27D70E1', 10, array('justification' => 'center'));
    
    $pdf->ezSetDy(-10); //perintah untuk memberikan jarak spasi paragraf
    
    //$pdf->line(50,1500,2273,1500); //perintah untuk membuat garis atas tabel
          
    $pdf->ezSetDy(-10);

    $pdf->ezText('LAPORAN PENJUALAN DARI TANGGAL: '.$dari.' SAMPAI  '.$sampai.'  ' , 12, array('justification' => 'center'));

    $pdf->ezSetDy(-10);
    
//$sql1 = mysql_query("SELECT * FROM transaksitbl");    
//$hasil = mysql_query($sql1);
//$numrows = mysql_num_rows($sql1);

   //echo "Pengulangan ke " . $x . "<br/>;

//while($cari = mysql_fetch_array($sql1)) {
    //$idx= $cari['notransaksi'];
    //$pdf->ezText($idx, 13, array('justification' => 'LEFT'));

//for($x=$cari['notransaksi']; $x<=$numrows; $x++)
//{
  
  $sql = mysql_query("select * from transaksirincitbl where tanggal BETWEEN '".$dari."' AND '".$sampai."'");    
    $i = 1;
    while($tampil = mysql_fetch_array($sql)) {
    
      $format_harga  = number_format($tampil['harga'], 0, ',', '.');  //format angka
      $format_total  = number_format($tampil['subtotal'], 0, ',', '.'); //format angka
      $semua=$tampil['total'];
                  //$totalproduk = $hargaproduk*$jumlah;
            //$totalsemua = ($totalsemua+$totalproduk);
      $totalsemua=($totalsemua+$semua);
       $ody="asdasdas";
      $data[$i]=array(
              'FAKTUR'=> $tampil['notransaksi'],    
              'MEMBER'=>$tampil['username'],
              'PRODUK'=>$tampil['nama'],
              'JUMLAH'=>$tampil['jumlah'],
              'HARGA'=>$format_harga,
              'BIAYA KIRIM'=>$tampil['biaya_kirim'],
              'KODE UNIK'=>$tampil['kode_unik'],
              'TOTAL'=>$tampil['total'],
              'TOTAL SEMUA' =>$totalsemua,

              
              
              );
                
      $i++;
        

    }
    
//$x++;
//}
//}
    //perintah untuk mengatur teks yang di cetak pada pdf
    //$pdf->ezStartText(100, 557, 12);
    //$pdf->ezStartText2(500, 557, 12);
    $pdf->ezStartPageNumbers(35, 15, 10);
    $pdf->ezTable($data, '', '', '');

    $pdf->ezSetDy(-50);
    
    $pdf->ezText('NB :', 13, array('justification' => 'LEFT')); //membuat teks NB di bawah tabel
    
    $pdf->ezStream();

  }
?>
