<?php session_start();
error_reporting(0);
if (ISSET($_SESSION['adminlogin']))
{
require("config.php");
$id = $_GET['id'];
$perintah = "DELETE from downloadtbl  where id = '$id'";
$result = mysql_query($perintah);
	if ($result) {
		header("location:download.php");
	} else { echo "Data belum dapat di hapus!!"; 
	}
}
?>