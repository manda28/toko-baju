<?php session_start();
if (ISSET($_SESSION['adminlogin']))
{
header("location:home.php"); 		
}
else
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>ShockingLabs</title>

<style type="text/css">
.Menu_Kiri {
	width: 100px;
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 16px;
	margin-top: 10px;
	margin-bottom: 10px;
}
.Menu_Tengah {
	width: 300px;
	margin-top: 10px;
	margin-left: 10px;
	margin-bottom: 10px;
		font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.Menu_Login {
	margin-top: 125px;
}
body {
	background-image: url(../Gambar/Background.gif);
}
</style>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationPassword.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationPassword.js" type="text/javascript"></script>
</head>

<body>
<div align="justify" class="Menu_Login">
  <table width="437" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
    <tr>
      <td colspan="2" align="center" valign="top"><img src="../Gambar/Header Login.png" width="450" height="80" /></td>
    </tr>
    <tr>
      <td width="100" align="center" valign="middle"><div class="Menu_Kiri"><img src="../Gambar/Login.gif" width="48" height="48" /></div></td>
      <td width="337" align="left" valign="top"><div class="Menu_Tengah">
        <form id="form1" name="form1" method="post" action="login.php">
          <table width="400" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="85">User Name</td>
              <td width="10">:</td>
              <td width="305"><label for="usertxt"></label>
                <span id="sprytextfield1">
                <label for="text1"></label>
                <input type="text" name="usertxt" id="usertxt" />
                <span class="textfieldRequiredMsg">Username Raoleh Kosong.</span></span></td>
              </tr>
            <tr>
              <td>Password</td>
              <td>:</td>
              <td><label for="pswtxt"></label>
                <span id="sprypassword1">
                <label for="password1"></label>
                <input type="password" name="pswtxt" id="pswtxt" />
                <span class="passwordRequiredMsg">Password Raoleh Kosong.</span></span></td>
              </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td><input type="submit" name="logbtn" id="logbtn" value="Login" /></td>
              </tr>
            </table>
          </form>
      </div></td>
    </tr>
    <tr>
      <td colspan="2" align="center" valign="top"><img src="../Gambar/Footer Login.png" width="450" height="56" /></td>
    </tr>
  </table>
</div>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprypassword1 = new Spry.Widget.ValidationPassword("sprypassword1");
</script>
</body>
</html>