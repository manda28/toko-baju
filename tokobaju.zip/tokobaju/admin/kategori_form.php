<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<form id="form1" name="form1" method="post" action="kategori_tambah.php">
  <table width="400" border="0" align="left">
    <tr>
      <td width="10%" align="left" valign="top">Kategori </td>
      <td width="1%" align="left" valign="top">:</td>
      <td width="89%" align="left" valign="top"><span id="sprytextfield1">
        <label for="ktgtxt"></label>
        <input type="text" name="ktgtxt" id="ktgtxt" />
      <span class="textfieldRequiredMsg">Harap diisi dulu.</span></span></span></td>
    </tr>
    <tr>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top"><label>
        <input type="submit" name="Submit" value="Simpan" />
      </label>
        <label>
          <input type="reset" name="Submit2" value="Batal" />
        </label>
        </span></td>
    </tr>
  </table>
</form>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
</script>
