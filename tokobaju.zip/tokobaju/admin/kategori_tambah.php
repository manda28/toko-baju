<?php session_start();
error_reporting(0);
if (ISSET($_SESSION['adminlogin']))
{
require("config.php");
$nama = $_POST['ktgtxt'];
$perintah = "INSERT INTO kategoritbl (nama)
VALUES ('$nama')";
$result = mysql_query($perintah);
	if ($result) {
		header("location:kategori.php");
	} else { echo "Data belum dapat di simpan!!"; 
	}
}
?>