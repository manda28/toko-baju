<?php session_start();
error_reporting(0);
if (ISSET($_SESSION['adminlogin']))
{
require("config.php");
$perintah = "UPDATE kategoritbl set nama = '$_POST[namatxt]' where id = '$_POST[idtxt]'";
$result = mysql_query($perintah);
	if ($result) {
		header("location:kategori.php");
	} else { echo "Data belum dapat di ubah!!"; 
	}
}
?>