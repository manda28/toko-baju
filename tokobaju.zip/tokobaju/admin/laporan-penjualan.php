<?php session_start();
require("../config.php");
if (ISSET($_SESSION['adminlogin']))
{
//Tidak ada event, dalam artian menghindari jump page  		
}
else
header("location:index.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>S</title>
  <link rel="stylesheet" href="cetak/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="cetak/jquery-1.12.4.js"></script>
  <script src="cetak/jquery-ui.js"></script>
  
<style type="text/css">
.Menu_Kiri {
	width: 150px;
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 14px;
	margin-top: 10px;
	margin-bottom: 10px;
}
body {
	background-image: url(../Gambar/Background.gif);
}
a:link {
	color: #006699;
}
a:visited {
	color: #006699;
}
a:hover {
	color: #5F9C9F;
}
a:active {
	color: #5F9C9F;
}
.Menu_Tengah {
	margin-top: 10px;
	margin-bottom: 10px;
	width: 600px;
	margin-left: 25px;
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.Teks_Keterangan {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
	color: #0096C3;
}
</style>

</head>
<script type="text/javascript">
    function validateForm()
    {
    var a=document.forms["laporan"]["dari"].value;
    var b=document.forms["cetak"]["sampai"].value;
    var c=document.forms["cetak"]["dari"].value;
    var d=document.forms["laporan"]["sampai"].value;
    if (a==null || a=="",b==null || b=="",c==null || c=="",d==null || d=="")
      {
      alert("Field Tidak Boleh Kosong");
      return false;
      }
    }
    </script>
<script>
 $(function(){
        $("#datepicker").datepicker({ dateFormat: 'yy-mm-dd' });
        $("#datepicker").datepicker({ dateFormat: 'yy-mm-dd' }).bind("change",function(){
            var minValue = $(this).val();
            minValue = $.datepicker.parseDate("yy-mm-dd", minValue);
            minValue.setDate(minValue.getDate()+1);
            $("#datepicker").datepicker( "option", "minDate", minValue );
        })
    });
  </script>
  <script>
  $(function(){
        $("#datepicker2").datepicker({ dateFormat: 'yy-mm-dd' });
        $("#datepicker2").datepicker({ dateFormat: 'yy-mm-dd' }).bind("change",function(){
            var minValue = $(this).val();
            minValue = $.datepicker.parseDate("yy-mm-dd", minValue);
            minValue.setDate(minValue.getDate()+1);
            $("#datepicker2").datepicker( "option", "minDate", minValue );
        })
    });
  </script>
<body>
<table width="800" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2" align="center" valign="top"><img src="../Gambar/Header.png" width="800" height="214" /></td>
  </tr>
  <tr>
    <td width="150" align="left" valign="top"><div class="Menu_Kiri">
      <ul>
        <li><a href="admin.php">Admin</a></li>
        <li><a href="produk.php">Produk</a></li>
        <li><a href="kategori.php">Menu Kategori</a></li>
        <li><a href="news.php">News</a></li>
        <li><a href="download.php">Download</a></li>
        <li><a href="laporan.php">Laporan</a></li>
		<li><a href="laporan_jualbeli.php">Laporan Laba Rugi</a></li>
        <li><a href="laporan-penjualan.php">Cetak laporan Penjualan<span style="color:red;font-size:12px;">(Baru)</span></a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
    </div></td>
    <td width="650" align="center" valign="top"><div class="Menu_Tengah"><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <th align="left" valign="top" class="Teks_Keterangan" scope="col">Menu Laporan</th>
  </tr>
  <tr>
    <td align="center" valign="top"><hr /></td>
  </tr>
  <tr>
    <td align="center" valign="top">
 
    <form onsubmit="return validateForm()" action="" method="POST" name="laporan">
   <label> Pilih Tanggal</label> <input type="text" id="datepicker" value="<?php if (isset($_POST['laporan'])) { echo $_POST['dari'];  }?>" name="dari"> <label> Pilih Sampai</label> <input value="<?php if (isset($_POST['laporan'])) { echo $_POST['sampai'];  }?>"  type="text" id="datepicker2" name="sampai"><input type="submit" value="Cari" name="laporan">
   </form>


 <?php
      if (isset($_POST['laporan'])) {
        $dari=$_POST['dari'];
        $sampai=$_POST['sampai'];
       
        echo '<h3>Data User</h3>
<table>
<tr>
<th>FAKTUR</th>
<th>MEMBER</th>
<th>PRODUK</th>
<th>JUMLAH</th>
<th>HARGA</th>
<th>BIAYA KIRIM</th>
<th>KODE UNIK</td>
<th>TOTAL</td>
</tr>
<tr>';

$i=0; 
 $sql="select * from transaksirincitbl where tanggal BETWEEN '".$dari."' AND '".$sampai."' ";


//perintah menampilkan data dikerjakan
$sql = mysql_query($sql);

//tampilkan seluruh data yang ada pada tabel user
while($tampil = mysql_fetch_array($sql))
 {
 $i++;

echo "
 <td>".$i."</td>
 <td>".$tampil['notransaksi']."</td>
 <td>".$tampil['username']."</td>
 <td>".$tampil['nama']."</td>
 <td>".$tampil['jumlah']."</td>
 <td> Rp. ".$tampil['harga'].",-</td>
 <td>".$tampil['biaya_kirim']."</td>
 <td>".$tampil['kode_unik']."</td>
 <td>Rp. ".$tampil['total'].",- </td>
 </tr>";
 }
echo '</table>';


      }
    ?>



<form method="POST" onsubmit="return validateForm()" name="cetak" action="cetak-laporan-penjualan.php">
<input type="submit" value="CETAK LAPORAN" name="cetak">
<div style="display:none;">
<input type="text" id="datepicker" value="<?php if (isset($_POST['laporan'])) { echo $_POST['dari'];  }?>" name="dari">
  <input value="<?php if (isset($_POST['laporan'])) { echo $_POST['sampai'];  }?>"  type="text" id="datepicker2" name="sampai">
</div>
</form>






  </tr>
    </table>
</div></td>
  </tr>
  <tr>
    <td colspan="2" align="center" valign="top"><img src="../Gambar/Footer.png" width="800" height="86" /></td>
  </tr>
</table>
</body>
</html>