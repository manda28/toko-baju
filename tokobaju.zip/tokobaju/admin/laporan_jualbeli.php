<?php 
error_reporting(0);
session_start();
if (ISSET($_SESSION['adminlogin']))
{
//Tidak ada event, dalam artian menghindari jump page  		
}
else
header("location:index.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>ShockingLabs</title>
<link rel="stylesheet" href="cetak/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  
<script src="cetak/jquery-1.12.4.js"></script>
  <script src="cetak/jquery-ui.js"></script>
  
<style type="text/css">
.Menu_Kiri {
	width: 150px;
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 14px;
	margin-top: 10px;
	margin-bottom: 10px;
}
body {
	background-image: url(../Gambar/Background.gif);
}
a:link {
	color: #006699;
}
a:visited {
	color: #006699;
}
a:hover {
	color: #5F9C9F;
}
a:active {
	color: #5F9C9F;
}
.Menu_Tengah {
	margin-top: 10px;
	margin-bottom: 10px;
	width: 600px;
	margin-left: 25px;
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.Teks_Keterangan {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
	color: #0096C3;
}
</style>

</head>
<script type="text/javascript">
    function validateForm()
    {
		vdari=document.getElementById("datepicker").value
		vsampai=document.getElementById("datepicker2").value
		if (vdari=="" || vsampai=="")
      {
		alert("Field Tidak Boleh Kosong");
		return false;
      }
	  else
	  {
		  return true
		  //alert("ok")
	  }
	 
	  
    }
    </script>
<script>
 $(function(){
        $("#datepicker").datepicker({ dateFormat: 'yy-mm-dd' });
        $("#datepicker").datepicker({ dateFormat: 'yy-mm-dd' }).bind("change",function(){
            var minValue = $(this).val();
            minValue = $.datepicker.parseDate("yy-mm-dd", minValue);
            minValue.setDate(minValue.getDate()+1);
            $("#datepicker").datepicker( "option", "minDate", minValue );
        })
    });
  </script>
  <script>
  $(function(){
        $("#datepicker2").datepicker({ dateFormat: 'yy-mm-dd' });
        $("#datepicker2").datepicker({ dateFormat: 'yy-mm-dd' }).bind("change",function(){
            var minValue = $(this).val();
            minValue = $.datepicker.parseDate("yy-mm-dd", minValue);
            minValue.setDate(minValue.getDate()+1);
            $("#datepicker2").datepicker( "option", "minDate", minValue );
        })
    });
  </script>
  
  
 

<body>
<table width="800" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">

 <tr>
    <td colspan="2" align="center" valign="top"><img src="../Gambar/Header.png" width="800" height="214" /></td>
  </tr>
  <tr>
    <td width="150" align="left" valign="top"><div class="Menu_Kiri">
      <ul>
        <li><a href="admin.php">Admin</a></li>
        <li><a href="produk.php">Produk</a></li>
        <li><a href="kategori.php">Menu Kategori</a></li>
        <li><a href="news.php">News</a></li>
        <li><a href="download.php">Download</a></li>
		<li><a href="laporan_jualbeli.php">Laporan Laba Rugi</a></li>
        <li><a href="laporan-penjualan.php">Cetak laporan Penjualan<span style="color:red;font-size:12px;">(Baru)</span></a></li>
        <li><a href="laporan.php">Laporan</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
    </div></td>
    <td width="650" align="center" valign="top"><div class="Menu_Tengah"><table width="100%" border="0" cellspacing="0" cellpadding="0">
     <tr>
    <th align="left" valign="top" class="Teks_Keterangan" scope="col">Laporan Laba Rugi Bulanan Distro ShockingLabs </th>
  </tr>
    <tr>
 	
	<?php
if (ISSET($_SESSION['adminlogin']))
{
}
else
header("location:index.php");
?>

<table width="600" border="1" cellpadding="0" cellspacing="0" bgcolor="#E8EED7">

 
<tr>
<td colspan=5>

    <form onsubmit="return validateForm()" action="" method="POST" name="laporan">
   <label> Pilih Tanggal</label>
   <input type="text" id="datepicker" value="<?php if (isset($_POST['laporan'])) { echo $_POST['dari'];  }?>" name="dari"> <label> Pilih Sampai</label> 
   <input value="<?php if (isset($_POST['laporan'])) { echo $_POST['sampai'];  }?>"  type="text" id="datepicker2" name="sampai">
   <input type="submit" value="Cari" name="laporan">
   <Br> <br>
   </form>


</td>

</tR> 


  <tr>
    <th width="5%" align="left" scope="col" >ID</th>
    <th width="15%" align="left" scope="col">Nama Produk</th>
    <th width="15%" align="left" scope="col">Total Pembelian</th>
    <th width="5%" align="left" scope="col">Total Penjualan</th>
  
    <th width="7%" align="right" scope="col">Keterangan</th>

</tr>

<?php
require("config.php");

/*
$query = "select *,sum(pembeliantbl.total_beli) as totalbeli,sum(transaksirincitbl.subtotal) as totaljual,barangtbl.nama,barangtbl.id 
from barangtbl left join pembeliantbl on barangtbl.id=pembeliantbl.id_barangtbl
left join transaksirincitbl on  barangtbl.id=transaksirincitbl.id 
group by barangtbl.id";

*/



      if (isset($_POST['laporan'])) {
        $dari=$_POST['dari'];
        $sampai=$_POST['sampai'];
       

$query = "select *,sum(pembeliantbl.total_beli) as totalbeli,sum(transaksirincitbl.subtotal) as totaljual,barangtbl.nama,barangtbl.id 
from barangtbl,pembeliantbl,transaksirincitbl 
where 
transaksirincitbl.id=barangtbl.id 
and pembeliantbl.id_barangtbl=barangtbl.id 
and (transaksirincitbl.tanggal >='$_POST[dari]' and transaksirincitbl.tanggal<='$_POST[sampai]') 
group by barangtbl.id";

$hasil = mysql_query($query);

while ($data = mysql_fetch_array($hasil))
{



	
echo "<tr>
<td align=\"left\" width=\"5%\" bgcolor=\"#FFFFFF\">".$data['id']."</td>
<td align=\"left\" width=\"10%\" bgcolor=\"#FFFFFF\">".$data['nama']."</td>
<td align=\"left\" width=\"10%\" bgcolor=\"#FFFFFF\">Rp " .number_format($data['totalbeli'], 0, ',', '.').",00</td>
<td align=\"left\" width=\"5%\" bgcolor=\"#FFFFFF\">Rp ".number_format($data['totaljual'], 0, ',','.').",00</td>";

$hasilakhir=$data['totaljual']-	$data['totalbeli'];
if ($hasilakhir>=0) { ?>
<td align=\"left\" width=\"5%\" bgcolor=\"#FFFFFF\"> <font  color='green'>Untung sebesar <?php echo number_format($hasilakhir, 0, ',','.') ?> </font>
<?php } else if ($hasilakhir<0) { ?>
<td align=\"left\" width=\"5%\" bgcolor=\"#FFFFFF\"> <font  color='red'> Rugi sebesar <?php echo number_format($hasilakhir, 0, ',','.') ?> </font>



<?php



}

echo "</tr>";

}
}

?>

</table>


<form method="POST" onsubmit="return validateForm()" name="cetak" action="cetak-laporan-jualbeli.php">
<input type="submit" value="CETAK LAPORAN" name="cetak">
<div style="display:none;">
<input type="text" id="datepicker" value="<?php if (isset($_POST['laporan'])) { echo $_POST['dari'];  }?>" name="dari">
  <input value="<?php if (isset($_POST['laporan'])) { echo $_POST['sampai'];  }?>"  type="text" id="datepicker2" name="sampai">
</div>
</form>

	
	
	
	
  </tr>
    </table>
</div></td>
  </tr>
  <tr>
    <td colspan="2" align="center" valign="top"><img src="../Gambar/Footer.png" width="1500" height="86" /></td>
  </tr>
</table>
</body>
</html>