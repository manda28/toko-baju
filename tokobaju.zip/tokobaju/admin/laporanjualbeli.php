<?php

//file pendukung class pdf dan koneksi ke database
require("../config.php");
include ('class.ezpdf.php');

//Pengaturan kertas untuk saat ini tipe kertas A4
$pdf =& new Cezpdf('A1','portrait');


		// Atur margin
		$pdf->ezSetCmMargins(1, 3, 3, 3);

		$pdf->addObject($all, 'all');
		$pdf->closeObject();
		
		//baris kode dibawah ini digunakan untuk mencetak info toko dalam pdf
		$pdf->ezText('ShockingLabs', 25, array('justification' => 'center'));
		$pdf->ezText('LAPORAN Laba Rugi', 15, array('justification' => 'center'));
		$pdf->ezText('Distro ShockingLabs', 15, array('justification' => 'center'));
		$pdf->ezSetDy(-10);
		$pdf->ezText('', 12, array('justification' => 'center'));
		$pdf->ezText('Jl. Cendrawasih no 4 A, Demangan Yogyakarta', 10, array('justification' => 'center'));
		$pdf->ezText('Shockinglabs.com / Telp : 08157916364  Email : shockinglabs@yahoo.co.id', 10, array('justification' => 'center'));
		
		$pdf->ezSetDy(-10); //perintah untuk memberikan jarak spasi paragraf
		
		//$pdf->line(50,1500,2273,1500); //perintah untuk membuat garis atas tabel
					
		$pdf->ezSetDy(-10);
		
		$sql = mysql_query("select *,sum(pembeliantbl.total_beli) as totalbeli,sum(transaksirincitbl.subtotal) as totaljual,barangtbl.nama,barangtbl.id from barangtbl left join pembeliantbl on barangtbl.id=pembeliantbl.id_barangtbl
						left join transaksirincitbl on  barangtbl.id=transaksirincitbl.id 
                        group by barangtbl.id"); 	 	
		$i = 1;
		while($tampil = mysql_fetch_array($sql)) {
			 
			$data[$i]=array('ID'=> $tampil['id'], 	 	
							'NAMA'=>$tampil['nama'],
							'TOTAL PEMBELIAN'=>$tampil['totalbeli'],
							'TOTAL PENJUALAN'=>$tampil['totaljual'],
	/*						'KETERANGAN'=>

$hasilakhir=$tampil['totaljual']-$tampil['totalbeli'];
if ($hasilakhir>=0) { ?>
<font  color='green'>Untung sebesar <?php echo number_format($hasilakhir, 0, ',','.') ?> </font>
<?php } else if ($hasilakhir<0) { ?>
 <font  color='red'> Rugi sebesar <?php echo number_format($hasilakhir, 0, ',','.') ?> </font>
 
 

<?php }  , */



							);
								
			$i++;
			
		}
		
		//perintah untuk mengatur teks yang di cetak pada pdf
		//$pdf->ezStartText(100, 557, 12);
		//$pdf->ezStartText2(500, 557, 12);
		$pdf->ezStartPageNumbers(35, 15, 10);
		$pdf->ezTable($data, '', '', '');
		$pdf->ezSetDy(-50);
		
		$pdf->ezText('NB :', 13, array('justification' => 'LEFT')); //membuat teks NB di bawah tabel
		
		$pdf->ezStream();
?>
