<?php session_start();
include("config.php");
$admin = $_POST['usertxt'];
$admin = str_replace("'","&acute;",$admin);
$psw=$_POST['pswtxt'];
$psw= str_replace("'","&acute;",$psw);
$cek = "Select * from admintbl where username='".$admin."' and password='".md5($psw)."'";
$hasil = mysql_query($cek);
$hasil_cek = mysql_num_rows($hasil);
if ($hasil_cek==0){
echo "<script>alert('Username atau Passwowd anda Salah')</script>";
echo "<meta http-equiv='refresh' content='0;url=index.php'>";//Username dan Password yang Anda isi salah...!!!";
}else{
$_SESSION['adminlogin'] =$admin;
header("location:home.php");
}
?>