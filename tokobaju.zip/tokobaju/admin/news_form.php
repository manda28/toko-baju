<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css" />
<form id="form1" name="form1" method="post" action="news_tambah.php">
  <table width="400" border="0" align="left">
    <tr>
      <td width="10%" align="left" valign="top">Judul </td>
      <td width="1%" align="left" valign="top">:</td>
      <td width="89%" align="left" valign="top"><span id="sprytextfield1">
        <label for="judultxt"></label>
        <input type="text" name="judultxt" id="judultxt" />
      <span class="textfieldRequiredMsg">Ojo Lali judul diisi.</span></span></span></td>
    </tr>
    <tr>
      <td align="left" valign="top">Berita</td>
      <td align="left" valign="top">:</td>
      <td align="left" valign="top"><label></label>
        <label></label>
        <span id="sprytextarea1">
        <label for="beritatxt"></label>
        <textarea name="beritatxt" id="beritatxt" cols="45" rows="5"></textarea>
        <span class="textareaRequiredMsg">berita mosok kosong ?.</span></span></td>
    </tr>
    <tr>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top"><hr /></td>
    </tr>
    <tr>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top"><label>
        <input type="submit" name="Submit" value="Simpan" />
      </label>
        <label>
          <input type="reset" name="Submit2" value="Batal" />
        </label>
        </span></td>
    </tr>
  </table>
</form>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextarea1 = new Spry.Widget.ValidationTextarea("sprytextarea1");
</script>
