<?php session_start();

if (ISSET($_SESSION['adminlogin']))
{
require("config.php");
$judul = $_GET['judul'];
$perintah = "DELETE from newstbl where judul = '$judul'";
$result = mysql_query($perintah);
	if ($result) {
		header("location:news.php");
	} else { echo "Data belum dapat di hapus!!"; 
	}
}
?>  