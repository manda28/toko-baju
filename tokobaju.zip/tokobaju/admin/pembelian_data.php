<?php
if (ISSET($_SESSION['adminlogin']))
{
}
else
header("location:index.php");
?>

<table width="600" border="1" cellpadding="0" cellspacing="0" bgcolor="#E8EED7">
  <tr>
   
    <th width="15%" align="left" scope="col">Nama Produk</th>
    <th width="7%" align="right" scope="col">Harga Beli</th>
    <th width="5%" align="right" scope="col">Jumlah</th>
    <th width="7%" align="left" scope="col" >Total Pembelian</th>

</tr>
 <?php  $hariini=date('Y-m-d'); ?>
<?php
require("config.php");
$query = "select * from pembeliantbl left join barangtbl on pembeliantbl.id_barangtbl=barangtbl.id where pembeliantbl.tgl_beli='$hariini' order by id_pembeliantbl desc ";
$hasil = mysql_query($query);
while ($data = mysql_fetch_array($hasil))
{
echo "<tr>

<td align=\"left\" width=\"10%\" bgcolor=\"#FFFFFF\">".$data['nama']."</td>
<td align=\"left\" width=\"10%\" bgcolor=\"#FFFFFF\">".$data['harga_beli']."</td>
<td align=\"left\" width=\"10%\" bgcolor=\"#FFFFFF\">".$data['jumlah']."</td>
<td align=\"left\" width=\"10%\" bgcolor=\"#FFFFFF\">".$data['total_beli']."</td>
</tr>";

}

?>

</table>
