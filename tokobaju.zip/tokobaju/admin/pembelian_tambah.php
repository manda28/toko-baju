<?php session_start();
error_reporting(0);
if (ISSET($_SESSION['adminlogin']))
{
require("config.php");
$tgl_beli = $_POST['tgl_beli'];
$idbarang = $_POST['idbarang'];
$harga_beli = $_POST['harga_beli'];
$jumlah = $_POST['jumlah'];
$totalpembelian=$harga_beli * $jumlah;

$perintah = "INSERT INTO pembeliantbl (id_barangtbl,tgl_beli,harga_beli,jumlah,total_beli)
VALUES ('$idbarang','$tgl_beli','$harga_beli','$jumlah','$totalpembelian')";
$result = mysql_query($perintah);

$cek="Select * from barangtbl where id=$idbarang";
$hasil=mysql_query($cek);
$data=mysql_fetch_array($hasil);
$totalstok=$data['stock']+$jumlah;

$updatestok="update barangtbl set stock='$totalstok' where id=$idbarang";
$resultstok=mysql_query($updatestok);




	if ($result) {
		header("location:pembelian_baranglama.php");
	} else { echo "Data belum dapat di simpan!!"; 
	}
}
?>