<?php session_start();
error_reporting(0);
if (ISSET($_SESSION['adminlogin']))
{
	if {empty($nama)}
		{echo "Nama: $nama <br />";
		}
		else
			die("maaf data kosong");
			
		}
require("config.php");
$nama = $_POST['namatxt'];
$des = $_POST['destxt'];
$ukr = $_POST['ukrtxt'];
$ktg = $_POST['ktglist'];
$hrg = $_POST['hrgtxt'];
$stk ='0';
$gbr = $_POST['gbrtxt'];
$berat = $_POST['berat'];
$perintah = "INSERT INTO barangtbl (nama,deskripsi,ukuran,kategori,harga,stock,gambar,berat)
VALUES ('$nama','$des','$ukr','$ktg','$hrg','$stk','$gbr','$berat')";
$result = mysql_query($perintah);
	if ($result) {
		header("location:pembelian_baranglama.php");
	} else { echo "Data belum dapat di simpan!!"; 
	}
}
?>