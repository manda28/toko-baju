<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
<form id="form1" name="form1" method="post" action="produk_tambah.php">
  <table width="400" border="0" align="left">
    <tr>
      <td width="10%" align="left" valign="top">Nama </td>
      <td width="1%" align="left" valign="top">:</td>
      <td width="89%" align="left" valign="top"><span id="sprytextfield1">
        <label for="namatxt"></label>
        <input type="text" name="namatxt" id="namatxt" />
      <span class="textfieldRequiredMsg">Isi Nama Barang Dulu.</span></span></span></td>
    </tr>
    <tr>
      <td align="left" valign="top">Deskripsi</td>
      <td align="left" valign="top">:</td>
      <td align="left" valign="top"><label></label>
        <label></label>
        <span id="sprytextarea1">
        <label for="destxt"></label>
        <textarea name="destxt" id="destxt" cols="45" rows="5"></textarea>
        <span class="textareaRequiredMsg">Deskripsi tidak boleh kosong.</span></span></td>
    </tr>
    <tr>
      <td align="left" valign="top">Ukuran</td>
      <td align="left" valign="top">:</td>
      <td align="left" valign="top"><label for="ukrtxt"></label>
        <span id="sprytextfield2">
        <label for="ukrtxt2"></label>
        <input type="text" name="ukrtxt" id="ukrtxt2" />
      <span class="textfieldRequiredMsg">Ojo Lali Ukuran.</span></span></td>
    </tr>
	
	<tr>
	<td align="left" valign="top">Warna</td>
	<td align="left" valign="top">:</td>
      <td align="left" valign="top"><label for="wrntxt"></label>
        <span id="sprytextfield3">
        <label for="wrntxt"></label>
        <input type="text" name="wrntxt" id="wrntxt" />
      <span class="textfieldRequiredMsg">Ojo Lali warna.</span></span></td>
    </tr>
	

  
    <tr>
      <td align="left" valign="top">Kategori</td>
      <td align="left" valign="top">:</td>
      <td align="left" valign="top"><label for="ktgtxt"></label>
        <label for="ktglist"></label>
        <select name="ktglist" size="1" id="ktglist">
            
      <?php
  require ("config.php");
  $perintah="select * from kategoritbl order by nama asc";
  $hasil=mysql_query($perintah);
  while ($data = mysql_fetch_array($hasil))
  
 {
  ?>
      <option value="<?php echo "$data[nama]"; ?>"><?php echo "$data[nama]"; }?></option>
      </select></td>
    </tr>
    <tr>
      <td align="left" valign="top">Harga</td>
      <td align="left" valign="top">:</td>
      <td align="left" valign="top"><label for="hrgtxt"></label>
        <span id="sprytextfield4">
        <label for="hrgtxt2"></label>
        <input type="text" name="hrgtxt" id="hrgtxt2" />
      <span class="textfieldRequiredMsg">Harga Diisi sek.</span></span></td>
    </tr>
    <tr>
      <td align="left" valign="top">Stock</td>
      <td align="left" valign="top">:</td>
      <td align="left" valign="top"><label for="stktxt"></label>
      <input type="text" name="stktxt" id="stktxt" readonly='true' disabled='true' value='0' /></td>
    </tr>
	 <tr>
      <td align="left" valign="top">Berat brg</td>
      <td align="left" valign="top">:</td>
      <td align="left" valign="top"><label for="stktxt"></label>
        <span id="sprytextfield5">
        <label for="berat"></label>
        <input type="text" name="berat" id="berat" />
       <span class="textfieldRequiredMsg">Harap isi Berat.</span></span></td>
    </tr>

    <tr>
      <td align="left" valign="top">Gambar</td>
      <td align="left" valign="top">:</td>
      <td align="left" valign="top"><label for="gbrtxt"></label>
      <input type="file" name="gbrtxt" id="gbrtxt" /></td>
    </tr>
    <tr>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top"><p>* Untuk gambar baik dengan ukuran 100 x 125 Pixels<br />
    * Setelah mengisi Form ini lalu masuk ke halaman Pembelian <a href="pembelian_tambah.php">(tambah stok</a>)<br />
      </p></td>
    </tr>
    <tr>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top"><hr /></td>
    </tr>
    <tr>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top"><label>
        <input type="submit" name="Submit" value="Simpan" />
      </label>
        <label>
          <input type="reset" name="Submit2" value="Batal" />
        </label>
        </span></td>
    </tr>
  </table>
</form>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextarea1 = new Spry.Widget.ValidationTextarea("sprytextarea1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3");
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4");
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield5");
</script>
