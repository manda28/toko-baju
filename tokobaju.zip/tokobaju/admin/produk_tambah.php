<?php session_start();
error_reporting(0);
if (ISSET($_SESSION['adminlogin']))
{
require("config.php");
$nama = $_POST['namatxt'];
$des = $_POST['destxt'];
$ukr = $_POST['ukrtxt'];
$wrn = $_POST['wrntxt'];
$ktg = $_POST['ktglist'];
$hrg = $_POST['hrgtxt'];
$stk = $_POST['stktxt'];
$gbr = $_POST['gbrtxt'];
$berat = $_POST['berat'];
$perintah = "INSERT INTO barangtbl (nama,deskripsi,ukuran,kategori,harga,stock,gambar,berat)
VALUES ('$nama','$des','$ukr','$ktg','$hrg','$stk','$gbr','$berat')";
$result = mysql_query($perintah);
	if ($result) {
		header("location:produk.php");
	} else { echo "Data belum dapat di simpan!!"; 
	}
}
?>