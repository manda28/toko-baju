<?php session_start();
if (ISSET($_SESSION['adminlogin']))
{
require("config.php");
$perintah = "UPDATE barangtbl set nama = '$_POST[namatxt]', deskripsi = '$_POST[destxt]',ukuran = '$_POST[ukrtxt]',warna= '$_POST[wrntxt]', kategori = '$_POST[ktglist]', harga = '$_POST[hrgtxt]', stock = '$_POST[stktxt]', berat = '$_POST[berat]', gambar = '$_POST[gbrtxt]' where id = '$_POST[idtxt]'";
$result = mysql_query($perintah);
	if ($result) {
		header("location:produk.php");
	} else { echo "Data belum dapat di ubah!!"; 
	}
}
?>