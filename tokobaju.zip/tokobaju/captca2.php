<style type="text/css">
.Captcha {
	width: 85px;
}
</style>

<div class="Captcha">
<form method="POST" action="cek_captcha.php">
&nbsp;<img src="random_captcha.php"><br>
<input type="text" size="5" name="check">
<br>
</br> 
</form>
</div>
