<style type="text/css">
.Captcha {
	width: 350px;
}
</style>
<?php
//error_reporting(0);
include "random_captcha2.php";
?>
<div class="Captcha">
<br>
<?php
echo "<span  style='background-color:#000;height:50px;width:50px;color:white;height:50px;width:100px;padding:10px;font-size:14pt;'>$_SESSION[capt]</span><Br>";
?>
<input type=hidden name=kodec id=kodec value="<?php echo $_SESSION['capt'];?>">
<input type="text" size="5" id="check" name="check" required>
<br>

</br> 
</div>
