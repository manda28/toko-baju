<style type="text/css">
.Captcha {
	width: 350px;
}
</style>

<div class="Captcha">
<form method="POST" action="cek_captcha.php">
&nbsp;<img src="random_captcha.php"><br>
<input type="text" size="5" name="check" required>
<br>
<input type="submit" name="submit" value="Simpan">
</br> 
</form>
</div>
