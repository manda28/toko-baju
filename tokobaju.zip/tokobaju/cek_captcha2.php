<?php
//session_start();
//if(($_POST['check']) == $_SESSION['check']) {
include("form_member.php");
include("simpan_member.php");
//}else{ 
//header("location:member.php");
//}
?>