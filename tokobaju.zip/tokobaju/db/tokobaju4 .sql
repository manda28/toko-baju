-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Inang: 127.0.0.1
-- Waktu pembuatan: 16 Nov 2016 pada 10.11
-- Versi Server: 5.5.27
-- Versi PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Basis data: `tokobaju4`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admintbl`
--

CREATE TABLE IF NOT EXISTS `admintbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(35) NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data untuk tabel `admintbl`
--

INSERT INTO `admintbl` (`id`, `username`, `password`) VALUES
(2, 'admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `admintblcontoh`
--

CREATE TABLE IF NOT EXISTS `admintblcontoh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(35) NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `bagian_produksi`
--

CREATE TABLE IF NOT EXISTS `bagian_produksi` (
  `Id_admin` int(20) NOT NULL,
  `Id_barang` int(10) DEFAULT NULL,
  `Nama_barang` varchar(25) DEFAULT NULL,
  `Jenis_barang` varchar(25) DEFAULT NULL,
  `Jumlah_barang` int(15) DEFAULT NULL,
  PRIMARY KEY (`Id_admin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `bank`
--

CREATE TABLE IF NOT EXISTS `bank` (
  `id_bank` int(10) NOT NULL AUTO_INCREMENT,
  `nama_bank` varchar(10) DEFAULT NULL,
  `atas_nama` varchar(25) NOT NULL,
  `no_rekening` varchar(25) NOT NULL,
  PRIMARY KEY (`id_bank`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `bank`
--

INSERT INTO `bank` (`id_bank`, `nama_bank`, `atas_nama`, `no_rekening`) VALUES
(1, 'BCA', 'fenny kurniawan', '4450946066');

-- --------------------------------------------------------

--
-- Struktur dari tabel `barangtbl`
--

CREATE TABLE IF NOT EXISTS `barangtbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(35) NOT NULL,
  `deskripsi` text NOT NULL,
  `ukuran` varchar(15) NOT NULL,
  `warna` varchar(15) NOT NULL,
  `kategori` varchar(25) NOT NULL,
  `harga` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  `gambar` varchar(50) NOT NULL,
  `berat` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Dumping data untuk tabel `barangtbl`
--

INSERT INTO `barangtbl` (`id`, `nama`, `deskripsi`, `ukuran`, `warna`, `kategori`, `harga`, `stock`, `gambar`, `berat`) VALUES
(27, 'kmjshc', 'kemeja kmjshc terbuat dari bahan flanel yang terkesan mewah, nyaman dipakai dan tidak panas di badan, tersedia dalam ukuran M dengan lebar bahu 47 cm, panjang lengan 57 cm, lebar lengan 12 cm, panjang baju 76 ', 'm', 'biru', 'Kemeja', 175000, 10, 'kemeja_sl.png', '0.05'),
(31, 'shcblw', 'baju shcblw terbuat dari bahan Cotton Combed yang tidak panas dipakai, nyaman dipakai, daya serap tinggi dan tidak mudah luntur, baju ini tersedia dalam ukuran M dengan lebar bahu 47 cm, panjang lengan 24 cm, lebar lengan 24 cm, dan panjang baju 71 cm. \r\n', 'm', 'biru', 'Baju', 110000, 10, 'baju_biru.jpg', '1'),
(32, 'havel', 'baju Havel terbuat dari bahan Cotton Combed yang tidak panas dipakai, nyaman dipakai, daya serap tinggi dan tidak mudah luntur, baju ini tersedia dalam ukuran L dengan lebar bahu 49 cm, panjang lengan 25 cm, lebar lengan 26 cm, dan panjang baju 73 cm. ', 'l', 'ijo', 'Baju', 125000, 10, 'baju_ijo.jpg', '1'),
(33, 'shcblck', 'baju shcblck terbuat dari bahan Cotton Combed yang tidak panas dipakai, nyaman dipakai, daya serap tinggi dan tidak mudah luntur, baju ini tersedia dalam ukuran L dengan lebar bahu 49 cm, panjang lengan 25 cm, lebar lengan 26 cm, dan panjang baju 73 cm. \r\n', 'l', 'hitam', 'Baju', 125000, 10, 'bajuhitam.jpg', '1'),
(34, 'jgp', 'celana jgn terbuat dari bahan parasut yang nyaman digunakan dan tidak panas, celana jgp ini tersedia dalam ukuran s atau sama dengan ukuran 27-28 :ukuran Pinggang 79 cm Panjang 92 cm. \r\n', 's', 'coklat', 'Celana', 175000, 0, 'jgp02.png', '1'),
(35, 'jogerpants', 'celana jogerpants terbuat dari bahan jogger yang sedang trend saat ini, nyaman digunakan dan tidak panas, celana jgp ini tersedia dalam ukuran s atau sama dengan ukuran 27-28 :ukuran Pinggang 79 cm Panjang 92 cm. ', 's', 'kuning', 'Celana', 250000, 10, 'jgp01.png', '1'),
(36, 'cln03', 'celana 03 terbuat dari bahan parasut yang nyaman digunakan dan tidak panas, celana jgp ini tersedia dalam ukuran s atau sama dengan ukuran 27-28 :ukuran Pinggang 79 cm Panjang 92 cm. \r\n       ', 's', 'abu-abu', 'Celana', 250000, 10, 'BJ005.png', '1'),
(37, 'explr', 'baju Explr terbuat dari bahan Cotton Combed yang tidak panas dipakai, nyaman dipakai, daya serap tinggi dan tidak mudah luntur, baju ini tersedia dalam ukuran M dengan lebar bahu 47 cm, panjang lengan 24 cm, lebar lengan 24 cm, dan panjang baju 71 cm. \r\n                  ', 'm', 'ijo', 'Baju', 110000, 10, 'bajuijo.jpg', '1'),
(39, 'cynpdk', 'kemeja cynpdk terbuat dari bahan cotton yang nyaman dipakai, tidak panas, dan tidak mudah luntur, kemeja cynpdk tersedia dalam ukuran L dengan lebar bahu 49 cm, panjang lengan 25 cm, lebar lengan 26 cm, dan panjang ', 'l', 'putih', 'Kemeja', 250000, 20, 'kemejaputihpendek.jpg', '1'),
(40, 'cotnpjg', 'kemeja cotnpjg terbuat dari bahan cotton yang nyaman dipakai, tidak panas, dan tidak mudah luntur, kemeja cynpdk tersedia dalam ukuran L dengan lebar bahu 49 cm, panjang lengan 61 cm, lebar lengan 13 cm, dan panjang ', 'l', 'putih', 'Kemeja', 250000, 10, 'kemejaputihpanjang.jpg', '1'),
(41, 'hikkss', 'Topi Hikkss terbuat dari bahan Rafel yang tebal sehingga tidak mudah rusak, ukuran lingkar kepala Lingkar kepala 55,5-57cm \r\n               ', 'm', 'biru', 'topi', 125000, 5, 'topi_biru.jpg', '1'),
(42, 'hikss', 'Topi Hikss terbuat dari bahan Rafel yang tebal sehingga tidak mudah rusak, ukuran lingkar kepala Lingkar kepala 57,5- 59cm \r\n', 'l', 'merah', 'topi', 125000, 5, 'topi_merah.jpg', '1'),
(43, 'bagsch', 'tas bagsch terbuat dari kanvas yang kuat dan tidak mudah rusak, tas ini berukuran lebar 40 cm, dan panjang 50 cm \r\n', 's', 'coklat', 'tas', 250000, 10, 'tas_coklat.jpg', '1'),
(44, 'bagylw', 'tas bagylw terbuat dari bahan Dinier yang populer saat ini, ukuran tas ini adalah L dengan panjang 60 cm dan lebar 50 cm ', 'l', 'abu-abu', 'tas', 250000, 10, 'taskuning.jpg', '1'),
(45, 'bagschl', 'tas bagschl terbuat dari bahan Dinier yang populer saat ini, ukuran tas ini adalah M dengan panjang 63 cm dan lebar 40 cm \r\n         ', 'm', 'biru', 'tas', 250000, 20, 'tasbiru.jpg', '1'),
(46, 'anbr01', 'Baju ini bermerk Anybeary, terbuat dari cotton yang sangat lembut, tidak panas saat dipakai, dan tidak mudah luntur, baju ini berukuran xl dengan lebar bahu 51 cm, panjang lengan 63 cm, lebar lengan 13 cm, panjang baju 78 cm.          ', 'xl', 'hitam', 'Baju Merk Lain', 170000, 5, 'anybeary.jpg', '1'),
(47, 'anbr02', 'Baju ini bermerk Anybeary, terbuat dari cotton yang sangat lembut, tidak panas saat dipakai, dan tidak mudah luntur, baju ini berukuran m dengan lebar bahu 47 cm, panjang lengan 60 cm, lebar lengan 12 cm, panjang baju 76 cm. \r\n         ', 'm', 'biru', 'Baju Merk Lain', 170000, 5, 'anybeary2.jpg', '1'),
(48, 'anbr03', 'Baju ini bermerk Anybeary, terbuat dari cotton yang sangat lembut, tidak panas saat dipakai, dan tidak mudah luntur, baju ini berukuran xl dengan lebar bahu 51 cm, panjang lengan 63 cm, lebar lengan 13 cm, panjang baju 78 cm.          ', 'xl', 'hitam', 'Baju Merk Lain', 170000, 4, 'anybeary3.jpg', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `downloadtbl`
--

CREATE TABLE IF NOT EXISTS `downloadtbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `judul` text NOT NULL,
  `deskripsi` text NOT NULL,
  `url` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `downloadtbl`
--

INSERT INTO `downloadtbl` (`id`, `judul`, `deskripsi`, `url`) VALUES
(1, 'Katalog Produk 2016', 'Informasi mengenai produk - produk terbaru tahun 2016, lengkap beserta harga, merk tipe, dan lain - lain.', 'download/KATALOG.PDF');

-- --------------------------------------------------------

--
-- Struktur dari tabel `hubungi`
--

CREATE TABLE IF NOT EXISTS `hubungi` (
  `Nama_pengguna` varchar(25) NOT NULL,
  `Email` varchar(25) NOT NULL,
  `Subject` varchar(30) NOT NULL,
  `Pesan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `jasa_pemgirim`
--

CREATE TABLE IF NOT EXISTS `jasa_pemgirim` (
  `kurir` varchar(25) DEFAULT NULL,
  `berat` int(25) DEFAULT NULL,
  `kota_tujuan` varchar(15) DEFAULT NULL,
  `jenis_pengiriman` varchar(15) DEFAULT NULL,
  `biaya_kirim` int(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategoritbl`
--

CREATE TABLE IF NOT EXISTS `kategoritbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data untuk tabel `kategoritbl`
--

INSERT INTO `kategoritbl` (`id`, `nama`) VALUES
(1, 'Kemeja'),
(2, 'Baju'),
(3, 'Celana'),
(4, 'Jaket'),
(5, 'topi'),
(6, 'tas'),
(7, 'Baju Merk Lain');

-- --------------------------------------------------------

--
-- Struktur dari tabel `konfirmasi`
--

CREATE TABLE IF NOT EXISTS `konfirmasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kode_unik` int(4) DEFAULT NULL,
  `username` varchar(20) NOT NULL,
  `status_pembayaran` enum('Belum Bayar','Sudah Bayar','Kadaluarsa') NOT NULL DEFAULT 'Belum Bayar',
  `id_transaksirincitbl` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data untuk tabel `konfirmasi`
--

INSERT INTO `konfirmasi` (`id`, `kode_unik`, `username`, `status_pembayaran`, `id_transaksirincitbl`) VALUES
(1, 384, 'ody', 'Sudah Bayar', 1),
(2, 928, 'ody', 'Sudah Bayar', 1),
(3, 390, 'ody', 'Sudah Bayar', 1),
(4, 85, 'ody', 'Sudah Bayar', 1),
(5, 567, 'ody', 'Sudah Bayar', 1),
(6, 92, 'ody', 'Sudah Bayar', 1),
(7, 678, 'ody', 'Sudah Bayar', 1),
(8, 159, 'putra', 'Sudah Bayar', 1),
(9, 568, 'putra', 'Sudah Bayar', 1),
(10, 79, 'putra', 'Sudah Bayar', 1),
(11, 518, 'putra', 'Sudah Bayar', 1),
(12, 79, 'putra', 'Kadaluarsa', 1),
(13, 775, 'putra', 'Sudah Bayar', 1),
(14, 385, 'putra', 'Sudah Bayar', 1),
(15, 732, 'putra', 'Sudah Bayar', 1),
(16, 843, 'putra', 'Sudah Bayar', 1),
(17, 730, 'putra', 'Sudah Bayar', 1),
(18, 651, 'putra', 'Sudah Bayar', 1),
(19, 706, 'aldi', 'Sudah Bayar', 1),
(20, 766, 'aldi', 'Sudah Bayar', 1),
(21, 176, 'aldi', 'Sudah Bayar', 1),
(22, 115, 'ody', 'Kadaluarsa', 1),
(23, 693, 'ody', 'Kadaluarsa', 1),
(24, 838, 'ody', 'Sudah Bayar', 1),
(25, 662, 'ody', 'Belum Bayar', NULL),
(26, 624, 'aldi', 'Belum Bayar', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `newstbl`
--

CREATE TABLE IF NOT EXISTS `newstbl` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `tanggal` date NOT NULL,
  `judul` varchar(50) NOT NULL,
  `news` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data untuk tabel `newstbl`
--

INSERT INTO `newstbl` (`id`, `tanggal`, `judul`, `news`) VALUES
(4, '2016-08-14', 'pameran distro', 'pameran distro di jec september 2016'),
(5, '2016-10-31', 'pameran', 'pameran di jec');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggantbl`
--

CREATE TABLE IF NOT EXISTS `pelanggantbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(35) NOT NULL,
  `alamat` text NOT NULL,
  `email` text NOT NULL,
  `telepon` varchar(25) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data untuk tabel `pelanggantbl`
--

INSERT INTO `pelanggantbl` (`id`, `nama`, `alamat`, `email`, `telepon`, `username`, `password`) VALUES
(27, 'putra', 'jl tentara pelajar no 18 Temanggung', 'putra@gmail.com', '085725898989', 'putra', '9d279ec8dadff908e61347ce60a5a4cc'),
(28, 'siti sofiah', 'glagahsari no 26 yogyakarta', 'sitisofiah@gmail.com', '085741089977', 'sofi', 'dcb76da384ae3028d6aa9b2ebcea01c9'),
(29, 'aldi suryadi', 'jl glagahsari no 33 yogyakarta', 'aldisuryadi@gmail.com', '085725898907', 'aldi', '827ccb0eea8a706c4c34a16891f84e7b'),
(30, 'rere', 'klaten', 'rere@gmail.com', '086765688767', 'rere', '827ccb0eea8a706c4c34a16891f84e7b'),
(33, 'ody permana putra', 'jln glagahsari no 18 yogyakarta', 'odipermanaputra@gmail.com', '085741078869', 'ody', '9d279ec8dadff908e61347ce60a5a4cc');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembeliantbl`
--

CREATE TABLE IF NOT EXISTS `pembeliantbl` (
  `id_pembeliantbl` int(11) NOT NULL AUTO_INCREMENT,
  `id_barangtbl` int(11) NOT NULL,
  `tgl_beli` date NOT NULL,
  `harga_beli` varchar(10) NOT NULL,
  `jumlah` int(4) NOT NULL,
  `total_beli` varchar(10) NOT NULL,
  PRIMARY KEY (`id_pembeliantbl`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=147 ;

--
-- Dumping data untuk tabel `pembeliantbl`
--

INSERT INTO `pembeliantbl` (`id_pembeliantbl`, `id_barangtbl`, `tgl_beli`, `harga_beli`, `jumlah`, `total_beli`) VALUES
(1, 21, '2016-08-09', '10000', 200, '2000000'),
(2, 22, '2016-08-09', '20000', 200, '4000000'),
(3, 23, '2016-08-09', '200000', 5, '1000000'),
(4, 23, '2016-08-09', '200000', 5, '1000000'),
(5, 24, '2016-08-09', '125000', 1, '125000'),
(6, 25, '2016-08-09', '125000', 5, '625000'),
(7, 25, '2016-08-09', '125000', 5, '625000'),
(8, 18, '2016-08-10', '250000', 3, '750000'),
(9, 18, '2016-08-10', '100000', 3, '300000'),
(10, 26, '2016-08-13', '130000', 3, '390000'),
(11, 26, '2016-08-13', '130000', 3, '390000'),
(12, 26, '2016-08-13', '130000', 3, '390000'),
(13, 26, '2016-08-13', '130000', 3, '390000'),
(14, 26, '2016-08-13', '130000', 3, '390000'),
(15, 27, '2016-08-13', '175000', 3, '525000'),
(16, 28, '2016-08-15', '125000', 3, '375000'),
(17, 29, '2016-08-16', '225000', 5, '1125000'),
(18, 30, '2016-08-19', '95000', 5, '475000'),
(19, 32, '2016-08-19', '50000', 2, '100000'),
(20, 36, '2016-08-19', '125000', 1, '125000'),
(21, 37, '2016-08-19', '35000', 5, '175000'),
(22, 38, '2016-08-19', '125000', 1, '125000'),
(24, 27, '2016-08-19', '125000', 5, '625000'),
(25, 28, '2016-08-19', '25000', 1, '25000'),
(26, 29, '2016-08-19', '450000', 5, '2250000'),
(27, 31, '2016-08-19', '50000', 5, '250000'),
(28, 28, '2016-08-22', '50000', 5, '250000'),
(29, 29, '2016-08-23', '200000', 5, '1000000'),
(30, 30, '2016-08-30', '150000', 3, '450000'),
(31, 30, '2016-08-31', '225000', 3, '675000'),
(32, 27, '2016-08-31', '125000', 3, '375000'),
(33, 0, '0000-00-00', '', 0, '0'),
(34, 0, '0000-00-00', '', 0, '0'),
(35, 31, '2016-09-24', '100000', 5, '500000'),
(36, 0, '0000-00-00', '', 0, '0'),
(37, 32, '2016-09-24', '100000', 5, '500000'),
(38, 0, '0000-00-00', '', 0, '0'),
(39, 34, '2016-09-25', '150000', 5, '750000'),
(40, 0, '0000-00-00', '', 0, '0'),
(41, 35, '2016-09-25', '150000', 5, '750000'),
(42, 0, '0000-00-00', '', 0, '0'),
(43, 36, '2016-09-25', '150000', 5, '750000'),
(44, 0, '0000-00-00', '', 0, '0'),
(45, 37, '2016-09-25', '100000', 5, '500000'),
(46, 0, '0000-00-00', '', 0, '0'),
(47, 38, '2016-09-25', '150000', 5, '750000'),
(48, 0, '0000-00-00', '', 0, '0'),
(49, 39, '2016-09-25', '150000', 5, '750000'),
(50, 0, '0000-00-00', '', 0, '0'),
(51, 40, '2016-09-25', '150000', 5, '750000'),
(52, 0, '0000-00-00', '', 0, '0'),
(53, 41, '2016-09-25', '75000', 5, '375000'),
(54, 0, '0000-00-00', '', 0, '0'),
(55, 42, '2016-09-25', '75000', 5, '375000'),
(56, 0, '0000-00-00', '', 0, '0'),
(57, 43, '2016-09-25', '135000', 5, '675000'),
(58, 0, '0000-00-00', '', 0, '0'),
(59, 33, '2016-09-25', '75000', 5, '375000'),
(60, 0, '0000-00-00', '', 0, '0'),
(61, 44, '2016-09-25', '135000', 5, '675000'),
(62, 0, '0000-00-00', '', 0, '0'),
(63, 43, '2016-09-25', '135000', 5, '675000'),
(64, 0, '0000-00-00', '', 0, '0'),
(65, 45, '2016-09-25', '135000', 5, '675000'),
(66, 0, '0000-00-00', '', 0, '0'),
(67, 0, '0000-00-00', '', 0, '0'),
(68, 32, '2016-09-27', '100000', 5, '500000'),
(69, 0, '0000-00-00', '', 0, '0'),
(70, 32, '2016-09-27', '100000', 5, '500000'),
(71, 0, '0000-00-00', '', 0, '0'),
(72, 37, '2016-09-27', '100000', 5, '500000'),
(73, 0, '0000-00-00', '', 0, '0'),
(74, 45, '2016-09-27', '150000', 5, '750000'),
(75, 0, '0000-00-00', '', 0, '0'),
(76, 44, '2016-09-27', '150000', 5, '750000'),
(77, 0, '0000-00-00', '', 0, '0'),
(78, 45, '2016-09-27', '150000', 5, '750000'),
(79, 0, '0000-00-00', '', 0, '0'),
(80, 43, '2016-09-27', '150000', 5, '750000'),
(81, 0, '0000-00-00', '', 0, '0'),
(82, 45, '2016-09-27', '80000', 10, '800000'),
(83, 0, '0000-00-00', '', 0, '0'),
(84, 42, '2016-09-27', '80000', 10, '800000'),
(85, 41, '2016-09-27', '80000', 10, '800000'),
(86, 0, '0000-00-00', '', 0, '0'),
(87, 39, '2016-09-27', '150000', 10, '1500000'),
(88, 0, '0000-00-00', '', 0, '0'),
(89, 40, '2016-09-27', '150000', 10, '1500000'),
(90, 0, '0000-00-00', '', 0, '0'),
(91, 31, '2016-09-27', '80000', 10, '800000'),
(92, 0, '0000-00-00', '', 0, '0'),
(93, 33, '2016-09-27', '80000', 10, '800000'),
(94, 0, '0000-00-00', '', 0, '0'),
(95, 0, '0000-00-00', '', 0, '0'),
(96, 34, '2016-09-27', '150000', 10, '1500000'),
(97, 0, '0000-00-00', '', 0, '0'),
(98, 45, '2016-09-27', '125000', 10, '1250000'),
(99, 0, '0000-00-00', '', 0, '0'),
(100, 45, '2016-10-01', '150000', 10, '1500000'),
(101, 0, '0000-00-00', '', 0, '0'),
(102, 45, '2016-10-01', '200000', 10, '2000000'),
(103, 0, '0000-00-00', '', 0, '0'),
(104, 44, '2016-10-01', '200000', 10, '2000000'),
(105, 0, '0000-00-00', '', 0, '0'),
(106, 43, '2016-10-01', '200000', 10, '2000000'),
(107, 0, '0000-00-00', '', 0, '0'),
(108, 42, '2016-10-01', '100000', 5, '500000'),
(109, 0, '0000-00-00', '', 0, '0'),
(110, 41, '2016-10-01', '100000', 5, '500000'),
(111, 0, '0000-00-00', '', 0, '0'),
(112, 40, '2016-10-01', '200000', 10, '2000000'),
(113, 0, '0000-00-00', '', 0, '0'),
(114, 39, '2016-10-01', '200000', 10, '2000000'),
(115, 39, '2016-10-01', '200000', 10, '2000000'),
(116, 0, '0000-00-00', '', 0, '0'),
(117, 37, '2016-10-01', '100000', 10, '1000000'),
(118, 0, '0000-00-00', '', 0, '0'),
(119, 36, '2016-10-01', '200000', 10, '2000000'),
(120, 0, '0000-00-00', '', 0, '0'),
(121, 35, '2016-10-01', '200000', 10, '2000000'),
(122, 0, '0000-00-00', '', 0, '0'),
(123, 45, '2016-10-01', '150000', 10, '1500000'),
(124, 0, '0000-00-00', '', 0, '0'),
(125, 33, '2016-10-01', '100000', 10, '1000000'),
(126, 0, '0000-00-00', '', 0, '0'),
(127, 32, '2016-10-01', '100000', 10, '1000000'),
(128, 0, '0000-00-00', '', 0, '0'),
(129, 31, '2016-10-01', '100000', 10, '1000000'),
(130, 0, '0000-00-00', '', 0, '0'),
(131, 27, '2016-10-01', '140000', 10, '1400000'),
(132, 0, '0000-00-00', '', 0, '0'),
(133, 0, '0000-00-00', '', 0, '0'),
(134, 0, '0000-00-00', '', 0, '0'),
(135, 46, '2016-10-01', '160000', 5, '800000'),
(136, 0, '0000-00-00', '', 0, '0'),
(137, 47, '2016-10-01', '160000', 5, '800000'),
(138, 0, '0000-00-00', '', 0, '0'),
(139, 48, '2016-10-01', '150000', 5, '750000'),
(140, 0, '0000-00-00', '', 0, '0'),
(141, 0, '0000-00-00', '', 0, '0'),
(142, 47, '2016-10-01', '160000', 5, '800000'),
(143, 0, '0000-00-00', '', 0, '0'),
(144, 48, '2016-10-01', '160000', 5, '800000'),
(145, 0, '0000-00-00', '', 0, '0'),
(146, 0, '0000-00-00', '', 0, '0');

-- --------------------------------------------------------

--
-- Struktur dari tabel `resi`
--

CREATE TABLE IF NOT EXISTS `resi` (
  `Id_resi` int(25) NOT NULL,
  `Id_kurir` int(10) DEFAULT NULL,
  `status` varchar(25) NOT NULL,
  `service` varchar(25) NOT NULL,
  `tanggal_kirim` date NOT NULL,
  `nama_pengirim` varchar(25) NOT NULL,
  `tujuan_kirim` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tambah_stok`
--

CREATE TABLE IF NOT EXISTS `tambah_stok` (
  `id_barang` int(10) DEFAULT NULL,
  `tanggal` datetime DEFAULT NULL,
  `jumlah_barang` int(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `testimonialtbl`
--

CREATE TABLE IF NOT EXISTS `testimonialtbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(35) NOT NULL,
  `tanggal` date NOT NULL,
  `testimonial` text NOT NULL,
  `email` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data untuk tabel `testimonialtbl`
--

INSERT INTO `testimonialtbl` (`id`, `nama`, `tanggal`, `testimonial`, `email`) VALUES
(2, 'siti sofiah', '2016-09-25', 'barang pesanan saya sudah sampai dengan cepat, barangnya juga memuaskan', 'sitisofiah@gmail.com'),
(3, 'aldi suryadi', '2016-09-25', 'wah keren sekali kemeja saya yang saya pesan sudah sampai dan hasilnya tidak mengecewakan, thanksyou shockinglabs', 'aldisuryadi@gmail.com'),
(4, 'rere', '2016-09-25', 'topinya keren sekali,pas buat saya pakai, sampai rumah juga tepat waktu, thanks shockinglabs', 'rere@gmail.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksirincitbl`
--

CREATE TABLE IF NOT EXISTS `transaksirincitbl` (
  `id_transaksirincitbl` int(11) NOT NULL AUTO_INCREMENT,
  `notransaksi` int(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `id` int(11) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `harga` int(25) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `ukuran` varchar(5) NOT NULL,
  `subtotal` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `kurir` varchar(11) NOT NULL,
  `berat` int(3) NOT NULL,
  `kota_tujuan` varchar(50) NOT NULL,
  `nama_tujuan` varchar(50) NOT NULL,
  `alamat_lengkap` text NOT NULL,
  `jenis_pengiriman` varchar(50) NOT NULL,
  `biaya_kirim` int(11) NOT NULL,
  `estimasi` varchar(10) NOT NULL,
  `kode_unik` int(4) NOT NULL,
  `id_bank` int(5) NOT NULL,
  `total` int(10) NOT NULL,
  PRIMARY KEY (`id_transaksirincitbl`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Dumping data untuk tabel `transaksirincitbl`
--

INSERT INTO `transaksirincitbl` (`id_transaksirincitbl`, `notransaksi`, `username`, `id`, `nama`, `harga`, `jumlah`, `ukuran`, `subtotal`, `tanggal`, `kurir`, `berat`, `kota_tujuan`, `nama_tujuan`, `alamat_lengkap`, `jenis_pengiriman`, `biaya_kirim`, `estimasi`, `kode_unik`, `id_bank`, `total`) VALUES
(1, 162, 'ody', 27, 'kemeja', 150000, 20, 'xl', 150000, '2016-08-14', 'tiki', 1, 'Aceh Singkil', 'kjhkjh', 'kjhkjhkjhkj', 'REG (REGULAR SERVICE) ', 82500, '3', 384, 1, 232884),
(3, 164, 'ody', 27, 'kemeja', 150000, 5, 'xl', 750000, '2016-08-14', 'pos', 1, 'Temanggung', 'permana', 'kauman rt/rw 05/06 parakan', 'Express Next Day (Express Next Day) ', 16500, '1', 390, 1, 766890),
(4, 165, 'ody', 27, 'kemeja', 150000, 1, 'xl', 150000, '2016-08-14', 'tiki', 1, 'Temanggung', 'putra', 'sambungsari rt/rw 5/4', 'ECO (ECONOMY SERVICE) ', 21000, '', 85, 1, 171085),
(6, 167, 'ody', 29, 'polo', 250000, 1, 'm', 250000, '2016-08-16', 'pos', 1, 'Aceh Tengah', 'permana', 'kuwaluhan rt/rw 5/4', 'Surat Kilat Khusus (Surat Kilat Khusus) ', 21500, '2-4', 92, 1, 271592),
(7, 168, 'ody', 27, 'kemeja', 150000, 1, 'xl', 150000, '2016-08-22', 'pos', 1, 'Aceh Tengah', 'paijo', 'payah', 'Surat Kilat Khusus (Surat Kilat Khusus) ', 21500, '2-4', 678, 1, 172178),
(29, 188, 'ody', 48, 'anbr03', 170000, 1, 'xl', 170000, '2016-10-30', 'tiki', 1, 'Yogyakarta', '', '', 'REG (REGULAR SERVICE) ', 8000, '3', 115, 1, 178115),
(30, 189, 'ody', 43, 'bagsch', 250000, 1, 's', 250000, '2016-10-30', 'pos', 1, 'Temanggung', 'putra', 'jl tentara pelajar no 18', 'Surat Kilat Khusus (Surat Kilat Khusus) ', 17000, '2', 693, 1, 267693),
(31, 190, 'ody', 48, 'anbr03', 170000, 1, 'xl', 170000, '2016-10-31', 'pos', 1, 'Yogyakarta', '', '', 'Surat Kilat Khusus (Surat Kilat Khusus) ', 6000, '2', 838, 1, 176838),
(33, 192, 'ody', 35, 'jogerpants', 250000, 1, 's', 250000, '0000-00-00', '', 1, '', '', '', '', 0, '', 0, 0, 0),
(34, 193, 'aldi', 48, 'anbr03', 170000, 1, 'xl', 170000, '2016-11-09', 'pos', 1, 'Yogyakarta', '', '', 'Surat Kilat Khusus (Surat Kilat Khusus) ', 6000, '2', 624, 1, 176624);

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksitbl`
--

CREATE TABLE IF NOT EXISTS `transaksitbl` (
  `notransaksi` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `status` int(15) NOT NULL,
  PRIMARY KEY (`notransaksi`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=194 ;

--
-- Dumping data untuk tabel `transaksitbl`
--

INSERT INTO `transaksitbl` (`notransaksi`, `username`, `status`) VALUES
(1, 'ody', 1),
(2, 'ody', 1),
(3, 'ody', 1),
(6, 'admin', 1),
(7, 'ody', 1),
(8, 'ody', 1),
(9, 'ody', 1),
(10, 'ody', 1),
(11, 'ody', 1),
(12, 'masmul', 1),
(13, 'masmul', 1),
(14, 'masmul', 1),
(15, 'masmul', 1),
(16, 'masmul', 1),
(17, 'masmul', 1),
(18, 'masmul', 1),
(19, 'masmul', 1),
(20, 'masmul', 1),
(21, 'masmul', 1),
(22, 'masmul', 1),
(23, 'masmul', 1),
(24, 'masmul', 1),
(25, 'masmul', 1),
(26, 'masmul', 1),
(27, 'masmul', 1),
(28, 'masmul', 1),
(29, 'masmul', 1),
(30, 'masmul', 1),
(31, 'masmul', 1),
(32, 'masmul', 1),
(33, 'masmul', 1),
(34, 'masmul', 1),
(35, 'masmul', 1),
(36, 'masmul', 1),
(37, 'masmul', 1),
(38, 'masmul', 1),
(39, 'masmul', 1),
(40, 'masmul', 1),
(41, 'masmul', 1),
(42, 'masmul', 1),
(43, 'masmul', 1),
(44, 'masmul', 1),
(45, 'masmul', 1),
(46, 'masmul', 1),
(47, 'masmul', 1),
(48, 'masmul', 1),
(49, 'masmul', 1),
(50, 'masmul', 1),
(51, 'ody', 1),
(52, 'ody', 1),
(53, 'masmul', 1),
(54, 'ody', 1),
(55, 'ody', 1),
(56, 'ody', 1),
(57, 'ody', 1),
(58, 'ody', 1),
(59, 'ody', 1),
(60, 'ody', 1),
(62, 'ody', 1),
(63, 'ody', 1),
(64, 'ody', 1),
(65, 'ody', 1),
(66, 'ody', 1),
(67, 'ody', 1),
(68, 'ody', 1),
(69, 'putra', 1),
(70, 'ody', 1),
(71, 'ody', 1),
(72, 'ody', 1),
(73, 'ody', 1),
(74, 'ody', 1),
(75, 'ody', 1),
(76, 'ody', 1),
(77, 'ody', 1),
(78, 'ody', 1),
(79, 'ody', 1),
(80, 'ody', 1),
(81, 'ody', 1),
(82, 'ody', 1),
(83, 'ody', 1),
(84, 'ody', 1),
(85, 'ody', 1),
(86, 'ody', 1),
(87, 'ody', 1),
(88, 'ody', 1),
(89, 'ody', 1),
(90, 'ody', 1),
(91, 'ody', 1),
(92, 'ody', 1),
(93, 'ody', 1),
(94, 'ody', 1),
(95, 'ody', 1),
(96, 'ody', 1),
(97, 'ody', 1),
(98, 'ody', 1),
(99, 'ody', 1),
(100, 'ody', 1),
(101, 'ody', 1),
(102, 'ody', 1),
(103, 'ody', 1),
(104, 'ody', 1),
(105, 'ody', 1),
(106, 'ody', 1),
(107, 'ody', 1),
(108, 'ody', 1),
(109, 'ody', 1),
(110, 'ody', 1),
(111, 'ody', 1),
(112, 'ody', 1),
(113, 'ody', 1),
(114, 'ody', 1),
(115, 'ody', 1),
(116, 'ody', 1),
(117, 'ody', 1),
(118, 'ody', 1),
(119, 'ody', 1),
(120, 'ody', 1),
(121, 'ody', 1),
(122, 'ody', 1),
(123, 'ody', 1),
(124, 'ody', 1),
(125, 'ody', 1),
(126, 'ody', 1),
(127, 'ody', 1),
(128, 'ody', 1),
(129, 'ody', 1),
(130, 'ody', 1),
(131, 'ody', 1),
(132, 'ody', 1),
(133, 'ody', 1),
(134, 'ody', 1),
(135, 'ody', 1),
(136, 'ody', 1),
(137, 'ody', 1),
(138, 'ody', 1),
(139, 'ody', 1),
(140, 'ody', 1),
(141, 'ody', 1),
(142, 'ody', 1),
(143, 'ody', 1),
(144, 'ody', 1),
(145, 'ody', 1),
(146, 'ody', 1),
(147, 'ody', 1),
(148, 'ody', 1),
(149, 'ody', 1),
(150, 'ody', 1),
(151, 'ody', 1),
(152, 'ody', 1),
(153, 'ody', 1),
(154, 'ody', 1),
(155, 'ody', 1),
(156, 'ody', 1),
(157, 'ody', 1),
(158, 'ody', 1),
(159, 'ody', 1),
(160, 'ody', 1),
(161, 'ody', 1),
(162, 'ody', 1),
(163, 'ody', 1),
(164, 'ody', 1),
(165, 'ody', 1),
(166, 'ody', 1),
(167, 'ody', 1),
(168, 'ody', 1),
(169, '', 0),
(170, 'putra', 1),
(171, 'putra', 1),
(172, 'putra', 1),
(173, 'putra', 1),
(174, 'putra', 1),
(175, 'putra', 1),
(176, 'putra', 1),
(177, 'putra', 1),
(178, 'putra', 1),
(179, 'putra', 1),
(180, 'putra', 1),
(181, 'putra', 1),
(182, 'putra', 1),
(183, 'putra', 1),
(184, 'aldi', 1),
(185, 'aldi', 1),
(186, 'aldi', 1),
(187, 'aldi', 1),
(188, 'ody', 1),
(189, 'ody', 1),
(190, 'ody', 1),
(191, 'ody', 1),
(192, 'ody', 1),
(193, 'aldi', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `visitortbl`
--

CREATE TABLE IF NOT EXISTS `visitortbl` (
  `ip` int(11) NOT NULL,
  `time` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`time`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1478700214 ;

--
-- Dumping data untuk tabel `visitortbl`
--

INSERT INTO `visitortbl` (`ip`, `time`) VALUES
(0, 1368498420),
(0, 1368498503),
(0, 1368498733),
(0, 1368499016),
(0, 1368499042),
(0, 1368499194),
(0, 1368499579),
(0, 1368499593),
(0, 1368499638),
(0, 1368499664),
(11, 1368500516),
(1, 1478700213);

DELIMITER $$
--
-- Event
--
CREATE DEFINER=`root`@`localhost` EVENT `event_updatetransaksikadaluarsa` ON SCHEDULE EVERY 2 DAY STARTS '2016-07-29 00:00:00' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
	UPDATE konfirmasi left join transaksirincitbl on konfirmasi.kode_unik=transaksirincitbl.kode_unik
    
    SET konfirmasi.status_pembayaran = 'Kadaluarsa' WHERE DATE_ADD(transaksirincitbl.tanggal, INTERVAL 2 DAY) <= NOW() and status_pembayaran='Belum bayar' ;
   
END$$

DELIMITER ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
