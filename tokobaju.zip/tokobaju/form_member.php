<style type="text/css">
error_reporting(0);
.proses_member {
	width: 375px;
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
}
.catatan {
	width: 250px;
	font-family: "Palatino Linotype", "Book Antiqua", Palatino, serif;
	font-size: 10px;
	color: #930;
}
</style>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationPassword.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationPassword.js" type="text/javascript"></script>



<Script language=javascript>
function cek()
{
	kode1=document.getElementById("kodec").value
	kode2=document.getElementById("check").value
	
	if(kode1!=kode2)
	{
		alert("Captcha tidak cocok")
		return false
		
	}
	else
	{
		return true
	}
}
</script>

<div class="proses_member">
  <form id="form1" name="form1" method="post" action="cek_captcha2.php" onsubmit="return cek()">
    <table width="100%" border="0">
      <tr>
        <td width="89">Nama</td>
        <td width="10">:</td>
        <td width="241"><label for="namatxt"></label>
          <span id="sprytextfield1">
          <label for="namatxt2"></label>
          <input type="text" name="namatxt" required id="namatxt2" />
        <span class="textfieldRequiredMsg">Nama harus diisi.</span></span></td>
      </tr>
      <tr>
        <td>Alamat</td>
        <td>:</td>
        <td><span id="sprytextarea1">
          <label for="almtxt2"></label>
          <textarea name="almtxt" required id="almtxt2" cols="35" rows="5"></textarea>
        <span class="textareaRequiredMsg">Harap isi Alamat lengkap.</span></span></td>
      </tr>
      <tr>
        <td>Telepon</td>
        <td>:</td>
        <td><span id="sprytextfield2">
          <label for="telptxt"></label>
          <input type="text" name="tlptxt" required id="tlptxt" />
        <span class="textfieldRequiredMsg">No HP harus diisi.</span></span></td>
      </tr>
      <tr>
        <td>Email</td>
        <td>:</td>
        <td><label for="emailtxt2"></label>
          <span id="sprytextfield3">
          <label for="emailtxt"></label>
          <input type="text" name="emailtxt" required id="emailtxt" />
        <span class="textfieldRequiredMsg">Email wajib diisi.</span></span></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td><hr /></td>
      </tr>
      <tr>
        <td>User</td>
        <td>:</td>
        <td><label for="usertxt"></label>
          <span id="sprytextfield4">
          <label for="usertxt2"></label>
          <input type="text" name="usertxt" required id="usertxt2" />
        <span class="textfieldRequiredMsg">User wajib diisi.</span></span></td>
      </tr>
      <tr>
        <td width="89">Password</td>
        <td>:</td>
        <td><label for="pswtxt"></label>
          <span id="sprypassword1">
          <label for="pswtxt2"></label>
          <input type="password" name="pswtxt" required id="pswtxt2" />
        <span class="passwordRequiredMsg">Password harus diisi.</span></span></td>
      </tr>
      <tr>
        <td width="89">Re Password</td>
        <td>:</td>
        <td><label for="ulgpswtxt"></label>
          <span id="sprypassword2">
          <label for="ulgpswtxt2"></label>
          <input type="password" name="ulgpswtxt" required id="ulgpswtxt2" />
        <span class="passwordRequiredMsg">Ulangi Password Anda.</span></span></td>
      </tr>
	  <tr>
	  <td width="89">Captcha</td> <td>&nbsp;</td>
	  <td><?php include "captca3.php" ?>&nbsp;</td>
	  </tr>
      <tr>
        <td>&nbsp;</td>
       
        <td><input type="submit" name="simpanbtn" id="simpanbtn" value="Daftar" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td><div class="catatan">Sudah Punya Akun ? <a href="index.php">Klik Disini</a></div></td>
      </tr>
    </table>
  </form>
</div>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextarea1 = new Spry.Widget.ValidationTextarea("sprytextarea1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3");
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4");
var sprypassword1 = new Spry.Widget.ValidationPassword("sprypassword1");
var sprypassword2 = new Spry.Widget.ValidationPassword("sprypassword2");
</script>
