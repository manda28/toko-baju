<style type="text/css">
.proses_testimonial {
	width: 350px;
	margin-left: 2px;
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
}
</style>
<div class="proses_testimonial">
  <form id="form1" name="form1" method="post" action="cek_captcha.php">
    <table width="100%" border="0">
      <tr>
        <td></td>
        <td></td>
        <td><label for="namatxt"></label>
        <input name="namatxt" type="hidden" id="namatxt" size="20" value='<?php echo $_SESSION['nama']; ?>' readonly /></td>
      </tr>
      <tr>
        <td></td>
        <td></td>
        <td><label for="emailtxt"></label>
        <input name="emailtxt" type="hidden" id="emailtxt" size="20" value='<?php echo $_SESSION['email']; ?>' readonly  /></td>
      </tr>
      <tr>
        <td>Testimonial</td>
        <td>:</td>
        <td><label for="testitxt"></label>
        <textarea name="testitxt" id="testitxt" cols="30" rows="4" required></textarea></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td><?php include "captcha.php" ?>&nbsp;</td>
      </tr>
    </table>
  </form>
</div>
