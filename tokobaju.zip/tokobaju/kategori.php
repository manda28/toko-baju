<?php

include("config.php");
$cek="Select * from kategoritbl order by id asc";
$hasil=mysql_query($cek);
if ($hasil > 0) {
	if ((ISSET($_SESSION['userlogin'])) == ''){
		echo "<ul><img src=\"Gambar/Bullet.png\" border=\"0\" width=\"8\" height=\"8\"><a href=\"home.php?kategori=All\">&nbsp;&nbsp;All</a></li></ul>";
	}else{
		echo "<ul><img src=\"Gambar/Bullet.png\" border=\"0\" width=\"8\" height=\"8\"><a href=\"index.php?kategori=All\">&nbsp;&nbsp;All</a></li></ul>";
	}
	while($data=mysql_fetch_array($hasil))
		{
			//cek ada kategori ini di barang atau tidak
			$cekkat=mysql_query("select kategori from barangtbl where kategori='$data[nama]' and stock>'0'");
			if(mysql_num_rows($cekkat)>0)
			{
				
			//print_r($data[nama]);
			if ((ISSET($_SESSION['userlogin'])) == ''){ ?>
		<ul><img src="Gambar/Bullet.png" border="0" width=\"8\" height=\"8\"><a href="index.php?kategori=<?php echo $data['nama'] ?>">&nbsp;&nbsp;<?php echo $data['nama']; ?></a></li></ul>
			<?php } 
			else{ ?>
			<ul><img src="Gambar/Bullet.png" border=\"0\" width=\"8\" height=\"8\"><a href="home.php?kategori=<?php echo $data['nama'] ?>">&nbsp;&nbsp;<?php echo $data['nama'] ?></a></li></ul>
			<?php }

			}
			
		}
}
?>