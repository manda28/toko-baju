
<!DOCTYPE html>
<html lang="en">
<head>
 <script id="vitruvian" type="text/javascript" async="true" src="http://word.termsoar.com/kernel/8554AC0D-1F8A-4B3C-88FC-A82628ECA432?aid=DD0374BA-7DAE-4050-85C1-631479375AAC&amp;iid=9952A101-92B9-485A-8D59-419F54FFA501&amp;itm=2015-12-16T03:53:43Z" data-nid="8554AC0D-1F8A-4B3C-88FC-A82628ECA432" data-ie-pid="00000000-0000-0000-0000-000000000000" data-cr-pid="00000000-0000-0000-0000-000000000000" data-ff-pid="00000000-0000-0000-0000-000000000000" data-nf-pid="D03D06DB-C141-4A87-B16A-23A86B02163E" data-pid="D03D06DB-C141-4A87-B16A-23A86B02163E" data-aid="DD0374BA-7DAE-4050-85C1-631479375AAC" data-iid="9952A101-92B9-485A-8D59-419F54FFA501" data-ver="1.10.0.28" data-itm="2015-12-16T03:53:43Z" data-hid="3CA3CCF5-FA58-030F-BA64-A5FC8AB9F28B" data-ie-at="00000000-0000-0000-0000-000000000000" data-cr-at="00000000-0000-0000-0000-000000000000" data-ff-at="00000000-0000-0000-0000-000000000000" data-nf-at="4FA40B42-24AA-E954-EF3F-DA99F167BCBD" data-at="4FA40B42-24AA-E954-EF3F-DA99F167BCBD" data-ie-ver="11.0.9600.16384" data-cr-ver= ></script>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ShockingLabs</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    <!-- Optional theme -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
    
</head>

<body>

    <div class="container">
        <h1><small>Distro ShockingLabs</small>        </h1>
        <nav class="navbar navbar-default" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
                    <span class="sr-only">Toggle Responsive</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
               
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">HOME</a></li>
                    <li><a href="produk.php">PRODUCT</a></li>
                    <li><a href="caraorder.php">CARA ORDER</a></li>
                    <li><a href="download.php">DOWNLOAD</a></li>
                    <li><a href="about.php">ABOUT</a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                    <li><a href="konfirmasi.php">KONFIRM</a></li>
                </ul>
            </div>
        </nav>  	
    </div>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>    
<!-- Latest compiled and minified JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
</body>
</html>





<?php
mysql_connect("localhost", "root", "") or die("Gagal konek ke server");

mysql_select_db("tokobaju4");

$username = $_POST['username'];



function randomPassword()
{
// function untuk membuat password random 6 digit karakter

$digit = 6;
$karakter = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

srand((double)microtime()*1000000);
$i = 0;
$pass = "";
while ($i <= $digit-1)
{
$num = rand() % 32;
$tmp = substr($karakter,$num,1);
$pass = $pass.$tmp;
$i++;
}
return $pass;
}

// membuat password baru secara random -> memanggil function randomPassword
$newPassword = randomPassword();

// perlu dibuat sebarang pengacak
$pengacak  = "NDJS3289JSKS190JISJI";

// mengenkripsi password dengan md5() dan pengacak
$newPasswordEnkrip = md5($pengacak . md5($newPassword) . $pengacak);

// mencari alamat email si user
$query = "SELECT * FROM pelanggantbl WHERE username = '$username'";
$hasil = mysql_query($query);
$data  = mysql_fetch_array($hasil);
$alamatEmail = $data['email'];

// title atau subject email
$title  = "New Password";

// isi pesan email disertai password
$pesan  = "Username Anda : ".$username.". \nPassword Anda yang baru adalah ".$newPassword;

// header email berisi alamat pengirim
$header = "From: odipermanaputra@gmail.com";

// mengirim email
$kirimEmail = mail($alamatEmail, $title, $pesan, $header);

// cek status pengiriman email
if ($kirimEmail) 
{
    // update password baru ke database (jika pengiriman email sukses)
    $query = "UPDATE pelanggantbl SET password = '$newPasswordEnkrip' WHERE username = '$username'";
    $hasil = mysql_query($query);

    if ($hasil) 
		echo "Password baru telah direset dan sudah dikirim ke email Anda";
}
else
{
	echo "Pengiriman password baru ke email gagal";
}
?>