<?php
require("config.php");
$cek="Select * from newstbl order by id desc";
$hasil=mysql_query($cek);
while($data=mysql_fetch_array($hasil)){
echo "<br>
<b>$data[id]</b><br>

<a href='lihatnews.php'>$data[news]</a><br>";
} 
?>