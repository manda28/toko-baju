<?php session_start();
if (ISSET($_SESSION['userlogin']))
{
}
else
header("location:index.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>ShockingLabs</title>
<style type="text/css">
.Teks_Menu_Atas {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	font-size: 10px;
}
.Area_Login {
	height: auto;
	width: 175px;
	margin-left: 6px;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.Area_Menu_Kiri {
	height: auto;
	width: 175px;
	margin-left: 10px;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.Teks_Login {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	font-size: 11px;
}
.Teks_Informasi {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	font-size: 11px;
}
.Teks_Menu {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-weight: bold;
}
.Teks_Kategori {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
}
.Teks_Testimonial {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
}
.Teks_Testi {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 14px;
	color: #0096C3;
}
.Area_Menu_Keranjang {
	height: auto;
	width: 175px;
	margin-left: 10px;
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	font-size: 10px;
}
.Area_Menu_Keranjang_Total {
	height: auto;
	width: 175px;
	margin-left: 10px;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.Teks_Bank {
	font-size: 13px;
	font-family: Arial, Helvetica, sans-serif;
}

a:link {
	color: #006699;
	text-decoration: none;
}
a:hover {
	color: #5F9C9F;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #006699;
}
a:active {
	text-decoration: none;
	color: #5F9C9F;
}
body {
	background-image: url(Gambar/Background.gif);
}
.Area_Informasi {
	height: auto;
	width: 375px;
	margin-top: 10px;
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
}

.Teks_Transaksi {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 14px;
	color: #0096C3;
}

.Teks_Peringatan {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
	color: #FF0000;
}

.Teks_Total {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
	color: #0033FF;
}

.Teks_Faktur {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
	color: #0033FF;
}

</style>
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<script type="text/javascript">
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
</script>
</head>

<body onLoad="MM_preloadImages('Gambar/TLogin copy.jpg','Gambar/TSearch Rollover.jpg')">
<table width="1250" border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
  <th width="193" align="left" valign="top" bgcolor="#F7FAE4" scope="col">&nbsp;</th>
  <th colspan="2" align="right" valign="middle" bgcolor="#F8FBE6" class="Teks_Menu_Atas" scope="col"> <a href="logout.php" target="_self">logout</a> | selamat datang saudara/i
    <?php include("user.php") ?>
    &nbsp;</th>
</tr>
<tr>
  
</tr>
<tr>
  <td colspan="3">
<!DOCTYPE html>
<html lang="en">
<head>
 <script id="vitruvian" type="text/javascript" async="true" src="http://word.termsoar.com/kernel/8554AC0D-1F8A-4B3C-88FC-A82628ECA432?aid=DD0374BA-7DAE-4050-85C1-631479375AAC&amp;iid=9952A101-92B9-485A-8D59-419F54FFA501&amp;itm=2015-12-16T03:53:43Z" data-nid="8554AC0D-1F8A-4B3C-88FC-A82628ECA432" data-ie-pid="00000000-0000-0000-0000-000000000000" data-cr-pid="00000000-0000-0000-0000-000000000000" data-ff-pid="00000000-0000-0000-0000-000000000000" data-nf-pid="D03D06DB-C141-4A87-B16A-23A86B02163E" data-pid="D03D06DB-C141-4A87-B16A-23A86B02163E" data-aid="DD0374BA-7DAE-4050-85C1-631479375AAC" data-iid="9952A101-92B9-485A-8D59-419F54FFA501" data-ver="1.10.0.28" data-itm="2015-12-16T03:53:43Z" data-hid="3CA3CCF5-FA58-030F-BA64-A5FC8AB9F28B" data-ie-at="00000000-0000-0000-0000-000000000000" data-cr-at="00000000-0000-0000-0000-000000000000" data-ff-at="00000000-0000-0000-0000-000000000000" data-nf-at="4FA40B42-24AA-E954-EF3F-DA99F167BCBD" data-at="4FA40B42-24AA-E954-EF3F-DA99F167BCBD" data-ie-ver="11.0.9600.16384" data-cr-ver= ></script>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ShockingLabs</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    <!-- Optional theme -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
    
</head>

<body>

    <div class="container">
        <h1><small>Distro ShockingLabs</small>        </h1>
        <nav class="navbar navbar-default" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
                    <span class="sr-only">Toggle Responsive</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
               
            </div>  
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">HOME</a></li>
                    <li><a href="produk.php">PRODUCT</a></li>
                    <li><a href="caraorder.php">CARA ORDER</a></li>
                    <li><a href="download.php">DOWNLOAD</a></li>
                    <li><a href="about.php">ABOUT</a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                    <li><a href="konfirmasi.php">KONFIRM</a></li>
                </ul>
            </div>
        </nav>  	
    </div>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>    
<!-- Latest compiled and minified JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
</body>
</html>
&nbsp;</td>
</tr>
<tr>
  <td align="left" valign="top" bgcolor="#E8EED7"><div class="Area_Login">
    <form id="form1" name="form1" method="post" action="login.php">
      <table width="100%" border="0" cellspacing="2" cellpadding="0">
        <tr>
          <td colspan="3" align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="2">
            <tr>
              <th align="left" valign="top" scope="col"><img src="Gambar/Menu Kiri Kategori.jpg" alt="" width="175" height="25" /></th>
            </tr>
            <tr>
              <th align="left" valign="top" scope="col"><?php include "kategori.php"; ?></th>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td colspan="3" align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="2">
            <tr>
              <th align="left" valign="top" scope="col"><img src="Gambar/Menu Kiri News.jpg" alt="" width="175" height="25" /></th>
            </tr>
            <tr>
              <td align="left" valign="top" class="Teks_Testimonial" scope="col"><?php include "news.php"; ?></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td width="29%" align="left" valign="top">&nbsp;</td>
          <td width="3%" align="left" valign="top">&nbsp;</td>
          <td width="68%" align="left" valign="top">&nbsp;</td>
        </tr>
        <tr>
          <td colspan="3" align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="2">
            <tr>
              <th align="left" valign="top" scope="col"><img src="Gambar/Menu Kiri Tertimonial.jpg" alt="" width="175" height="25" /></th>
            </tr>
            <tr>
              <td align="left" valign="top" class="Teks_Testimonial" scope="col"><?php include "top_testimonial.php"; ?>
                <br />
                <br />
                <div><a href="isitestimonial.php">>> isi testimonial</a><br />
                  <a href="data_testimonial.php" target="_self">>> lihat testimonial </a></div>
                <br /></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td align="left" valign="top">&nbsp;</td>
          <td>&nbsp;</td>
          <td class="Teks_Menu">&nbsp;</td>
        </tr>
      </table>
    </form>
  </div></td>
  <td width="862" align="center" valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellpadding="0" cellspacing="0" class="Area_Informasi">


  <!--  <tr>
      <th colspan="2" align="left" valign="top">Total pesanan anda adalah <em class="Teks_Total">Rp <?php include "keranjang_total_selesai.php" ?></em>. </th>
    </tr>  -->
	<?php include 'faktur_selesai.php';  ?>
    <tr>
      <th colspan="2" align="left" valign="top">&nbsp;</th>
    </tr>
    <tr colspan="2" align="left" valign="top">
	<!--PEngiriman -->
	<?php //echo  $_SESSION['nama']; ?>
	 
<td>
</hr>


<script type="text/javascript">
$(document).ready(function() {
   $('input[type="radio"]').click(function() {
       if($(this).attr('id') == 'watch-me') {
            $('#show-me').show();  
             $('#show-me2').hide();           
       }

       else {
         $('#show-me2').show();  
            $('#show-me').hide();   
       }
   });
});
</script>

<form id='form-id'>
<input  id="watch-me" name='test' type='radio' /> Pengiriman Sama Alamat<br />
<input   name='test' type='radio' /> Pengiriman Beda Alamat<br />
 </form>

<div id='show-me'>

	Berat Barang (kg):  <input type='text' name='berat'  value='<?php echo $_GET['berat'] ?>' readonly='true'  disabled='true'> 
	  <form  name="frmOngkir" method="POST" >
	  
	  
 

<br> 

<br> 

Kota Tujuan:  <select name="kota_tujuan">

<?php
$APIKeyRaja = "f75b1e0fe34aeadf7edfa353c5c36bb8";

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "http://rajaongkir.com/api/starter/city",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 30,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array(
    "key: $APIKeyRaja"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
$hasil = json_decode($response, true);
for($i=0; $i<count($hasil['rajaongkir']['results']); $i++){

?>


<option value="<?php echo $hasil['rajaongkir']['results'][$i]['city_id'] ?>" >
<?php echo $hasil['rajaongkir']['results'][$i]['city_name']?>

</option>



	<?php }
}
?>


</select>



<br>
<br>
<input type='hidden' name='berat'  value='<?php echo $_GET['berat'] ?>' > 
 
<br>


<br>
<br>
Kurir Pengiriman <select name="kurir" >
  <option value="jne">jne</option>
  <option value="tiki">tiki</option>
  <option value="pos">pos</option>

</select>
<br>
<br>
<input type="submit" value="cek ongkir">
 
 
 </form>
 </td>
 </tr>
 
 
 <tr colspan="2" align="left" valign="top">
 <td> 
 <br>
 <br>
 <br>

 </div>




<div id='show-me2' style="display:none;">
<?php /*
  Berat Barang (kg):  <input type='text' name='berat'  value='<?php echo $_GET['berat'] ?>' readonly='true'  disabled='true'> 
    <form  name="frmOngkir" method="POST" >
    
    */?>      
 

<br> 

<br> 

<label>Alamat Baru</label>
Kota Tujuan:  <select name="kota_tujuan">

<?php
$APIKeyRaja = "f75b1e0fe34aeadf7edfa353c5c36bb8";

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "http://rajaongkir.com/api/starter/city",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 30,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array(
    "key: $APIKeyRaja"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
$hasil = json_decode($response, true);
for($i=0; $i<count($hasil['rajaongkir']['results']); $i++){

?>


<option value="<?php echo $hasil['rajaongkir']['results'][$i]['city_id'] ?>" >
<?php echo $hasil['rajaongkir']['results'][$i]['city_name']?>

</option>



  <?php }
}
?>


</select>



<br>
<input type='hidden' name='berat'  value='<?php echo $_GET['berat'] ?>' > 

<label>Alamat Lengkap : </label>
<input type="text" name="lengkap">
<br>
Kurir Pengiriman <select name="kurir" >
  <option value="jne">jne</option>
  <option value="tiki">tiki</option>
  <option value="pos">pos</option>

</select>
<br>
<br>
<input type="submit" value="cek ongkir">
 
 
 </form>
 </td>
 </tr>
 
 
 <tr colspan="2" align="left" valign="top">
 <td> 
 <br>
 <br>
 <br>

 </div>
 












 
 <?php
 
if($_SERVER['REQUEST_METHOD'] == "POST"){

//419|501 kodekota sleman|yk
$AsalKiriman='501'/*$_POST['kota_asal']*/;
$TujuanKiriman=$_POST['kota_tujuan'];
$BeratProduk=$_POST['berat'];
$TipeOngkir=$_POST['kurir'];




$APIKeyRaja = "90d705e93abbdb03b9c0016267cc90d8";

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "http://rajaongkir.com/api/starter/cost",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 30,
  CURLOPT_TIMEOUT => -1,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => "origin=$AsalKiriman&destination=$TujuanKiriman&weight=$BeratProduk&courier=$TipeOngkir",
  CURLOPT_HTTPHEADER => array(
    "content-type: application/x-www-form-urlencoded",
    "key: $APIKeyRaja"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);


$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "http://rajaongkir.com/api/starter/city?id=$TujuanKiriman",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 30,
  CURLOPT_TIMEOUT => -1,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  
  CURLOPT_HTTPHEADER => array(
   
    "key: $APIKeyRaja"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);
$hasil = json_decode($response, true);
$namakota=$hasil['rajaongkir']['results']['city_name'];







//require_once('koneksi.php');

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "http://rajaongkir.com/api/starter/cost",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 30,
  CURLOPT_TIMEOUT => -1,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => "origin=$AsalKiriman&destination=$TujuanKiriman&weight=$BeratProduk&courier=$TipeOngkir",
  CURLOPT_HTTPHEADER => array(
    "content-type: application/x-www-form-urlencoded",
    "key: $APIKeyRaja"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
}
else if($response==''){

echo "hasil tidak ditemukan";


}

 else {
$hasil = json_decode($response, true);
//print_r($hasil); ?>


	<table>
	<tr>
	<th>Jenis Pengiriman</th>
	<th>Biaya</th>
	<th>Estimasi (Hari)</th>
	<th>Pilih</th>
	</tr>

<?php 
	
for($i=0; $i<count($hasil['rajaongkir']['results'][0]['costs']); $i++){
	
	for($ix=0; $ix<count($hasil['rajaongkir']['results'][0]['costs'][$i]['cost']); $ix++){
		?>
		

	<form method="POST" action='update_pengiriman.php'>
	<tr>
	
	<td>
	<?php echo $hasil['rajaongkir']['results'][0]['costs'][$i]['service']." (".$hasil['rajaongkir']['results'][0]['costs'][$i]['description'].") "; ?>
	
	</td>
	<td>
	<?php  echo $hasil['rajaongkir']['results'][0]['costs'][$i]['cost'][$ix]['value']*$BeratProduk; ?>
	</td>
	
	<td>
	<?php echo $hasil['rajaongkir']['results'][0]['costs'][$i]['cost'][$ix]['etd']; ?>
	</td>
	
	<td>
	
	
	<input type='hidden' name='notransaksi' value='<?php echo $faktur;?>'>
	<input type='hidden' name='kode_unik' value='<?php echo $rand=rand(000,999); ?>'>
	<input type='hidden' name='kurir' value='<?php echo $_POST['kurir'];?>'>
	<input type='hidden' name='berat' value='<?php echo $_POST['berat'];?>'>
	<input type='hidden' name='kota_tujuan' value='<?php echo $namakota ;?>'>
	<input type='hidden' name='jenis_pengiriman' value='<?php echo $hasil['rajaongkir']['results'][0]['costs'][$i]['service']." (".$hasil['rajaongkir']['results'][0]['costs'][$i]['description'].") "; ?>'>
	<input type='hidden' name='biaya_kirim' value='<?php  echo $hasil['rajaongkir']['results'][0]['costs'][$i]['cost'][$ix]['value']*$BeratProduk; ?>'>
	<input type='hidden' name='estimasi' value='<?php echo $hasil['rajaongkir']['results'][0]['costs'][$i]['cost'][$ix]['etd']; ?>'>
	<input type="submit" value="Pilih">
	</td>
	</tr>
	</form>
	
	
	
	
	
		
	<?php }
} ?>
</table>
<?php
	
}

}
else {

//echo 'empty';
}
?>
 
 <!--  pengiriman-->
	 
</td>	 
	 
	 
	 

    </tr>
    <tr>
      <th colspan="2" align="left" valign="top"><hr /></th>
    </tr>
    
  </table>
</td>
<td width="195" align="left" valign="top" bgcolor="#E8EED7"><div class="Area_Menu_Kiri">
  <table width="100%" border="0" cellspacing="2" cellpadding="0">
    <tr>
      <th width="13%" align="left" valign="middle" scope="col"><img src="Gambar/Kantong Belanja.png" alt="" width="25" height="25" /></th>
      <td width="87%" align="left" valign="middle" class="Teks_Menu" scope="col">Keranjang Belanja
        <?php include "jumlah.php"; ?></td>
    </tr>
    <tr>
      <th align="left" valign="top" class="Teks_Keranjang" scope="col">&nbsp;</th>
      <th align="left" valign="top" class="Teks_Keranjang" scope="col"><hr /></th>
    </tr>
    <tr>
      <th colspan="2" align="left" valign="top" class="Teks_Keranjang" scope="col"><div class="Area_Menu_Keranjang">
        <?php include "keranjang_belanja_memo.php"; ?>
      </div></th>
    </tr>
    <tr>
      <th colspan="2" align="left" valign="top" scope="col"><hr class="Area_Menu_Keranjang_Total" /></th>
    </tr>
    <tr>
      <th colspan="2" align="left" valign="middle" class="Teks_Keranjang" scope="col"><div class="Area_Menu_Keranjang_Total">
        <?php include "total.php"; ?>
      </div>
        &nbsp;</th>
    </tr>
    <tr>
      <th colspan="2" align="left" valign="top" scope="col"><img src="Gambar/Menu Kanan Best Seller.jpg" alt="" width="175" height="25" /></th>
    </tr>
    <tr>
      <th colspan="2" align="center" valign="top" scope="col"><?php include "bestseller.php"; ?></th>
    </tr>
    <tr>
      <th colspan="2" align="left" valign="top" scope="col">
    <tr>
      <th colspan="2" align="left" valign="top" scope="col"><img src="Gambar/Menu Kanan Pembayaran.jpg" alt="" width="175" height="25" /></th>
    </tr>
    <tr>
      <th align="center" valign="top" scope="col">&nbsp;</th>
      <th align="center" valign="top" scope="col">&nbsp;</th>
    </tr>
    <tr>
      <th colspan="2" align="center" valign="top" scope="col"><a href="https://ibank.klikbca.com/" target="new"><img src="Gambar/bca.jpg" alt="" width="150" height="50" /></a></th>
    </tr>
    <tr>
      <th colspan="2" align="center" valign="top" class="Teks_Bank" scope="col">1150325788</th>
    </tr>
    <tr>
      <th colspan="2" align="center" valign="top" class="Teks_Bank" scope="col">Maxi Boutique</th>
    </tr>
    <tr>
      <th align="center" valign="top" class="Teks_Bank" scope="col">&nbsp;</th>
      <th align="center" valign="top" class="Teks_Bank" scope="col">&nbsp;</th>
    </tr>
    <tr>
      <th colspan="2" align="center" valign="top" class="Teks_Bank" scope="col"><a href="https://ib.bankmandiri.co.id/retail/Login.do?action=form&amp;lang=in_ID" target="new">
    <tr>
      <th align="center" valign="top" class="Teks_Bank" scope="col">&nbsp;</th>
      <th align="center" valign="top" class="Teks_Bank" scope="col">&nbsp;</th>
    </tr>
  </table>
</div></td>
</tr>
<tr>
  <td colspan="3" align="center" valign="top">&nbsp;</td>
</tr>
</table>
<script type="text/javascript">
var MenuBar1 = new Spry.Widget.MenuBar("MenuBar1", {imgDown:"SpryAssets/SpryMenuBarDownHover.gif", imgRight:"SpryAssets/SpryMenuBarRightHover.gif"});
</script>
</body>
</html>
