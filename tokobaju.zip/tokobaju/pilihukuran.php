
<?php
$size = explode(",", $data['ukuran']);
?>

<select name="ukr">
<?php foreach($size as $ukr): ?>
<option value="<?php echo $ukr; ?>"><?php echo $ukr; ?></option>
<?php endforeach; ?>
</select>