<style type="text/css">
.teks_nama_produk {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
	color: #000000;
}
.teks_harga_produk {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #990000;
	font-weight: bold;
}
</style>

<?php
if(!empty($_POST['txtcari']))
	$txtcari=$_POST['txtcari'];
else if(!empty($_GET['txtcari']))
	$txtcari=$_GET['txtcari'];
else
	$txtcari="";

if(!empty($_POST['pilihan']))
	$pilihan=$_POST['pilihan'];
else if(!empty($_GET['pilihan']))
	$pilihan=$_GET['pilihan'];
else
	$pilihan="";


if(!empty($txtcari) && !empty($pilihan))
{
	if($pilihan=="harga")
	{
		$batas=explode("-",$txtcari);
		$filter=" and ((harga>='$batas[0]' and harga<='$batas[1]') or harga='$txtcari') ";
	}
	else
	{
		$filter=" and $pilihan like '%$txtcari%' ";
	}
}
else
{
	$filter="";
}

echo "<form method='post' action=#>
<input type=text name=txtcari value='$txtcari' size=30 placeholder='ketik pencarian'> 
<select name=pilihan>
<option value=''>Semua Produk</option>";
$arpil=array("kategori","ukuran","harga","nama","warna");
for($i=0;$i<count($arpil);$i++)
{
	if($arpil[$i]==$pilihan)
	{
		echo "<option value='$arpil[$i]' selected>$arpil[$i]</option>";
	}
	else
	{
			echo "<option value='$arpil[$i]'>$arpil[$i]</option>";
	}
}
echo "
</select>
 <input type=submit value=Cari></form><hr>";


if(isset($_GET['kategori'])){$kategori = $_GET['kategori']; }
include("config.php");
if((isset($kategori)) ==''){
	//Menampilkan record product baru sebanyak 50 product
	$query = "select * from barangtbl where id<>'' $filter order by id desc LIMIT 0,50";
	$hasil = mysql_query($query);
	$numrows = mysql_num_rows($hasil);
}else{
	echo "<table width=\"100%\">
	<tr>
	<td align=\"center\"><b><font color=\"maroon\" size=\"2.5\">[ ".$_GET['kategori']." ]</b></font></td>
	</tr>
	</table>";
	$query = "select * from barangtbl where id<>'' and  kategori = '$kategori' $filter order by id desc LIMIT 0,25";
	$hasil = mysql_query($query);
	$numrows = mysql_num_rows($hasil);
	}
?>

<table border=0px cellpadding='10' cellspacing="2" bgcolor="" bordercolor="" align="left">
	<tr>
        
<?php
	$kolom=3;
	$x = 0;
	if($numrows > 0){
	while($data=mysql_fetch_array($hasil))
		{
		    if ($x >= $kolom) 
			    {
			      echo "</tr><tr>";
			      $x = 0;
				}
	$x++;
	
	

		if ($data['stock'] >0) {
?>

<td align=center>			 
	<div class ="teks_nama_produk">
    	<?php echo $data['nama']; ?><br><br>
		
    </div>
    
    <div>
		<img width='80px' height='105px' valign='top' border='1,5' src="produk/<?php echo $data['gambar']; ?>"><br><br>
	</div>		 
	
    <div class ="teks_harga_produk">
        <?php $hargarp = $data['harga'] ?>
        <?php echo "Rp " .number_format($hargarp, 0, ',', '.').",-" ?><br><br>
        Ukuran : <?php echo $data['ukuran']; ?>
	
    </div>
<script language="javascript">
function cekuser()
{
	vuser="<?php echo $_SESSION['userlogin'];?>"
	if(vuser=="")
	{
		alert("Anda harus login")
		return false
	}
	else
	{
		return true
	}
}
</script>
    <div>
      <!--  <?php
		echo '
	<a href="produk_beli.php?id='.$data['id'].'"><img src="Gambar/TBeli.jpg"\ title="Beli Sekarang" border="0" width=\"50\" height=\"30\"></a><a href="produk_detail.php?id='.$data['id'].'&size='.$data['ukuran'].'"><img src="Gambar/TDetail.jpg"\ title="Detail Barang" border="0" width=\"50\" height=\"30\"></a>';
		?> -->
		
		<?php
		if ($data['stock'] >0) {
		echo "
	<a href='produk_beli.php?id=$data[id]' onclick='return cekuser()'><img src='Gambar/TBeli.jpg' title='Beli Sekarang' border=0 width=50  height=30>";

	echo'</a><a href="produk_detail.php?id='.$data['id'].'&ukuran='.$data['ukuran'].'"><img src="Gambar/TDetail.jpg"\ title="Detail Barang" border="0" width=\"50\" height=\"30\"></a>';
	
	} 
	else 
	{
		echo '<a href="#"><input type="button" value="Stok Habis"></a>';
		if(!isset($_SESSION['#'])){ echo "Anda Harus Login"; }
	
	}
		?>
		
	</div>
        <hr />	
</td>
		<?php } else {} ?>
            
<?php
	}
	}
	else
	{
		echo "Produk tidak ditemukan";
	}
?>

</tr>
</table>
    