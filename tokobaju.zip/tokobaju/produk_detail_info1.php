<?php
error_reporting(0);
?>
<script src="script/jquery-1.4.js"></script>
  <script>
	$(document).ready(function(){
		$("#tombol").click(function(){
									
					vuser=$("#ceklogin").val();
					
					if(vuser=="")
					{
							alert("Anda harus daftar kemudian login");
							location.href="member.php";
							return false
					}
					else
					{
						$("#form100").submit()
					}
				})
	   })
	</script>
    
<style type="text/css">
.teks_info_produk {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
	color: #000000;
}
.teks_harga_produk {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #990000;
	font-weight: bold;
}
</style>

<?php
include("config.php");
$id = $_GET['id'];
$ukuran = $_GET['ukuran'];
	$query = "select * from barangtbl where id = '".$id."' AND ukuran = '".$ukuran."'";
	$hasil = mysql_query($query);
	$temukan = mysql_num_rows($hasil);
	$data = mysql_fetch_array($hasil);
	if($temukan==0){
	}else{
?>

<table border=0px cellpadding='10' cellspacing="2" bgcolor="" bordercolor="" align="center">
	<tr>
        
<td align=center>			 
	<div class ="teks_info_produk">
    	<?php echo $data['nama']; ?><br><br>
		Warna : <?php echo $data['warna']; ?><br><br>
		
 <form method='GET' action='produk_beli.php' id="form100" name="form100">     
 <input type="hidden" id="ceklogin" name="ceklogin" value="<?php echo $_SESSION['userlogin'];?>" />
Ukuran <?php
$size = explode(",", $data['ukuran']);
?>
<input type='hidden' name='id' value='<?php echo $data['id']; ?>'>
<select name="ukuran">
<?php foreach($size as $ukr): ?>
<option value="<?php echo $ukr; ?>"><?php echo $ukr; ?></option>
<?php endforeach; ?>
</select>


        
    </div>
    
    <div>
	<img width='200px' height='225px' valign='top' border='1,5' src="produk/<?php echo $data['gambar']; ?>"><br><br>
	</div>		
    
    <div class ="teks_info_produk">
    	<?php echo $data['deskripsi']; ?><br><br>
        Stock Barang : <?php echo $data['stock'];	?><br><br>
    </div> 
	
    <div class ="teks_harga_produk">
        <?php $hargarp = $data['harga'] ?>
        <?php echo "Rp " .number_format($hargarp, 0, ',', '.').",-" ?><br><br>
    


    <div>      <?php
		if ($data['stock'] >0) {
	/*	echo '
	<a href="produk_beli.php?id='.$data['id']' onclick='return cekuser()'><img src="Gambar/TBeli.jpg"\ title="Beli Sekarang" border="0" width=\"50\" height=\"30\"></a>'; */
	?>
	<input type='button' value='beli' id="tombol">

	<?php 
	} else {
		echo '<a href="#"><input type="button" value="Stok Habis"></a>';
		if(!isset($_SESSION['#'])){ echo "Anda Harus Login"; }
	
	}
		?>
	</div>
     <hr />
	 </form>
     
<?php
	}

?>
</td>    
</tr>
</table>
    