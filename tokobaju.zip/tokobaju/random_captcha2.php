<?php 
//session_start(); 
/*
//imagecreatefrompng :: membuat tampilan image baru 
//untuk lokas image sama dengan lokasi file index dengan nama black.png
$img = imagecreatefrompng('black.png'); 
//menampikan nilai random teks
$numero = rand(100, 999); 
$_SESSION['check'] = ($numero); 
//menggunakan sedikit pengaturan gambar
$white = imagecolorallocate($img, 255, 255, 255); 
imagestring($img, 10, 8, 3, $numero, $white);
 header ("Content-type: image/png"); imagepng($img); 
*/
$sumber=array("a","b","c","d","e","f","g","K","L","m","n","p","q","r","s","t","u","v","w","x","y","z","1","2","3","4","5","6","7","8",);
$teks=array();
while(count($teks)<3)
{
	$acak=rand(0,(count($sumber)-1));
	$teks[]=$sumber[$acak];
}
$_SESSION['capt']=implode("",$teks);



?>