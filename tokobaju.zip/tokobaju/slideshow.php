<?php
	include("nivoslideshow.php");
	$nivo=new NivoSlider('nivoslider',618,200);		// base path is same directory

	//$nivo->add_slide(ImagePath,URL,Caption);
	$nivo->add_slide('slideshow/nemo.jpeg','','');
	$nivo->add_slide('slideshow/toystory.jpeg','http://www.shockinglabs.com','Product Accesories ShockingLabs');	
	$nivo->add_slide('slideshow/up.jpeg','','');
	$nivo->add_slide('slideshow/walle.jpeg','','');
	
?>

<?php $nivo->render_includes(); ?>
<?php $nivo->render_slides() ?>
