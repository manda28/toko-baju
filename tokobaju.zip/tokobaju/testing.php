<?php session_start();
if (ISSET($_SESSION['userlogin']))
{
//Tidak ada event, dalam artian menghindari jump page  		
}
else
header("location:index.php");
?>