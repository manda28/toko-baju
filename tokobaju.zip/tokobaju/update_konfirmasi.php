<?php 
error_reporting(0);
session_start();

require("config.php");


//$kodeunik=$_SESSION['kode_unik'];
$kodeunik=$_POST['kode_unik'];
$usersubajingan=$_SESSION['userlogin']; 

$cek=mysql_query("select * from konfirmasi WHERE kode_unik = '$_POST[kode_unik]' and username='$_POST[username]' ");

$h=mysql_fetch_array($cek);

//echo $h['status_pembayaran'];

if (mysql_num_rows($cek)>0){


		if ($h['status_pembayaran']=='Kadaluarsa'){
		
				
		
		$cektransaksitbl=mysql_query("Select *  from transaksitbl 
		
								left join transaksirincitbl on  transaksitbl.notransaksi=transaksirincitbl.notransaksi

								left join konfirmasi on transaksirincitbl.kode_unik=konfirmasi.kode_unik 
								
								WHERE konfirmasi.kode_unik = '$_POST[kode_unik]' ");
		$h=mysql_fetch_array($cektransaksitbl);
		
		$delete_transaksitbl=mysql_query("DELETE  from transaksitbl where notransaksi='$h[notransaksi]' ");
		
		
						
		$delete_transaksirincitbl=mysql_query("DELETE  from transaksirincitbl where kode_unik='$_POST[kode_unik]' ");
								
								
		$delete_konfirmasi=mysql_query("DELETE  from konfirmasi WHERE kode_unik = '$_POST[kode_unik]' ");




/*

		
$kueri=mysql_query("UPDATE transaksirincitbl
left join konfirmasi on transaksirincitbl.`id_transaksirincitbl` = konfirmasi.id_transaksirincitbl
left join `barangtbl` on transaksirincitbl.`id` = barangtbl.id  
SET    barangtbl.stock=stock-transaksirincitbl.jumlah
where transaksirincitbl.username='".$usersubajingan."'' and konfirmasi.status_pembayaran='Sudah Bayar' and transaksirincitbl.id=ransaksirincitbl.id ");

*/


$stokdikurangi=$data2['stock']-$data['jumlah'];







		?>
		
		
		
		<script language="javascript">
			alert('Maaf Status Pembelian anda sudah kadaluarsa karena melampui waktu yang telah ditentukan *2hari');document.location='home.php';
		</script>
		
<?php		}
		elseif ($h['status_pembayaran']=='Belum Bayar')  {




$query=mysql_query("UPDATE konfirmasi SET 

									status_pembayaran ='Sudah Bayar'
	
									WHERE kode_unik = '$_POST[kode_unik]' and username='$_POST[username]'  ");
									
						  
							  
//header("location:transaksi_selesai.php");	
//baca id kode barang
$query3=mysql_query("select id,jumlah from transaksirincitbl where kode_unit='$kodeunik'");
while($data3=mysql_fetch_array($query3))
{
	mysql_query("update barangtbl set stock=stock-'$data3[jumlah]' where id='$data3[id]'");
}

	
	mysql_query("UPDATE transaksirincitbl, `konfirmasi`
    SET konfirmasi.`id_transaksirincitbl` = transaksirincitbl.id_transaksirincitbl
    WHERE transaksirincitbl.`id_transaksirincitbl`=transaksirincitbl.`id_transaksirincitbl`");

    mysql_query("UPDATE transaksirincitbl
left join konfirmasi on transaksirincitbl.`id_transaksirincitbl` = konfirmasi.id_transaksirincitbl
left join `barangtbl` on transaksirincitbl.`id` = barangtbl.id  
SET    barangtbl.stock=barangtbl.stock-transaksirincitbl.jumlah
where  transaksirincitbl.kode_unik='".$kodeunik."'"); 


?>
<script language="javascript">
alert('konfirmasi berhasil, terimakasih atas pembayaran anda');document.location='transaksi_selesai.php';
</script>	
<?php 

}
}

else {
	
?>
<script language="javascript">
alert('Maaf transaksi tidak ditemukan');document.location='konfirmasi.php';
</script>	
<?php 		
}



//$hasil=mysql_fetch_array($query);

?>
		