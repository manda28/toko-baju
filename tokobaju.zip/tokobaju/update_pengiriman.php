<?php 

require("config.php");
//$member = $_SESSION['userlogin'];
//print_r($_POST["notransaksi"]);

$unik=$_POST['kode_unik'];
$kurir=$_POST['kurir'];
$berat=$_POST['berat'];
$kota_tujuan=$_POST['kota_tujuan'];
$jenis_pengiriman=$_POST['jenis_pengiriman'];
$biaya_kirim=$_POST['biaya_kirim'];
$estimasi=$_POST['estimasi'];
$nama=$_POST['nama'];
$alamat=$_POST['alamat'];


$cari=mysql_query("select subtotal from transaksirincitbl where notransaksi='$_POST[notransaksi]'");

$r=mysql_fetch_array($cari);

$total=$biaya_kirim+$r['subtotal']+$unik;
//print_r($total);



$tgl=date('Y-m-d');


$query=mysql_query("UPDATE transaksirincitbl SET 
												
									kode_unik = '$unik',
									kurir = '$kurir',
									 berat = '$berat',
									kota_tujuan = '$kota_tujuan',
									jenis_pengiriman = '$jenis_pengiriman',
									biaya_kirim = '$biaya_kirim',		
									estimasi = '$estimasi',
									total ='$total',
									tanggal='$tgl',
									nama_tujuan='$nama',
									alamat_lengkap='$alamat'
									
									
									WHERE notransaksi = '$_POST[notransaksi]'   ");
							  
							 // print_r($query);
							  
		header("location:pilih_tujuan.php");	


//$hasil=mysql_fetch_array($query);

?>
		