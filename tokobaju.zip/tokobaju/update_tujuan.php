<?php 

require("config.php");
//$member = $_SESSION['userlogin'];
//print_r($_POST["notransaksi"]);



$cari=mysql_query("select username,kode_unik from transaksirincitbl where notransaksi='$_POST[notransaksi]'");

$r=mysql_fetch_array($cari);


$query=mysql_query("UPDATE transaksirincitbl SET 

									id_bank ='$_POST[id_bank]'
	
									WHERE notransaksi = '$_POST[notransaksi]'   ");
									
$insert=mysql_query("INSERT INTO konfirmasi (kode_unik,username,status_pembayaran)
									values ('$r[kode_unik]','$r[username]','Belum Bayar') ");
//print_r($insert);
							  
							  
header("location:transaksi_selesai.php");	


//$hasil=mysql_fetch_array($query);

?>
		