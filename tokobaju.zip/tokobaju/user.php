<?php 
if(isset($_SESSION['userlogin'])) {
	echo "<Font color=\"Gyan\">".$_SESSION['userlogin'];
}
?>